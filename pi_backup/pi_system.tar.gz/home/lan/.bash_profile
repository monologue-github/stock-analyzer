if [ -z "$SSH_CLIENT" ] && [ "$(tty)" = "/dev/tty1" ]; then
  export FRAMEBUFFER=/dev/fb1
echo "BP-MARKER $(date)" >> /tmp/bp.log
  while :; do
    startx -- -nocursor vt1
    sleep 3
  done
fi
