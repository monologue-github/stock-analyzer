#!/bin/bash
export FRAMEBUFFER=/dev/fb1
cd /home/lan/stock_predict
while :; do
  python3 stock_gui.py >> /tmp/stock_gui.log 2>&1
  sleep 5
done
