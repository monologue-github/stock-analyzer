#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""股票形态相似度预测工具 GUI 增强版（腾讯行情源，纯标准库）

  - K线主图 + MA5/10/20/30/60（可勾选）+ 买卖点标记
  - 成交量副图
  - 可选指标副图：MACD / KDJ / RSI
  - 十字光标：对齐右侧价格轴与下方日期轴，显示当日OHLC
  - 右侧栏：预测结果与相似历史参考日期
  - 周期切换 / 复制报告 / 导出报告 / 样本明细

仅统计参考，不构成投资建议。
"""
import configparser
import heapq
import json
import json
import math
import os
import random
import sqlite3
import subprocess
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

CACHE_OK = True


# ================= 内嵌缓存层（原 stock_cache.py，单文件化）
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "stock_cache.db")
INI_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "stock_gui.ini")
KLINE_URL = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"
UT = "fa5fd1943c7b386f172d6893dbfba10b"
TIERS = ("大盘", "中盘", "小盘")
STOCKS_TTL = 7 * 86400          # 全市场代码表缓存7天
INIT_LOCK = threading.Lock()
REFRESH_LOCK = threading.Lock()

# 默认池大小（可被 analyze 的参数覆盖）
L2_DEFAULT_N = 50               # 同行业同伴数
L3_DEFAULT_N = 100              # 同市值层抽样数


# ================= 基础 =================

def _cx():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def init_db():
    with INIT_LOCK:
        conn = _cx()
        try:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS daily_bars(
                    code TEXT NOT NULL, date TEXT NOT NULL,
                    open REAL, high REAL, low REAL, close REAL, vol REAL,
                    PRIMARY KEY(code, date));
                CREATE INDEX IF NOT EXISTS idx_bars_code
                    ON daily_bars(code, date);
                CREATE TABLE IF NOT EXISTS stocks(
                    code TEXT PRIMARY KEY, name TEXT, industry TEXT,
                    mktcap REAL, tier TEXT, updated TEXT);
                CREATE TABLE IF NOT EXISTS meta(
                    key TEXT PRIMARY KEY, value TEXT);
                CREATE TABLE IF NOT EXISTS failed(
                    code TEXT PRIMARY KEY, ts REAL);
            """)
            conn.commit()
        finally:
            conn.close()


init_db()


def _get_meta(conn, key):
    row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return row[0] if row else None


def _set_meta(conn, key, value):
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)",
                 (key, str(value)))


# ================= 代理 =================

_PROXY_OPENER = None            # 仅K线等 stock_cache 内部请求走代理


def set_proxy(url):
    """设置K线数据源代理（只影响 stock_cache 的请求；
    行情快照/板块等国内接口保持直连）。url 形如 http://127.0.0.1:7890。"""
    global _PROXY_OPENER
    url = (url or "").strip()
    try:
        if not url:
            _PROXY_OPENER = None
            return ""
        if not url.startswith("http"):
            url = "http://" + url
        handler = urllib.request.ProxyHandler({"http": url, "https": url})
        _PROXY_OPENER = urllib.request.build_opener(handler)
        return url
    except Exception:
        _PROXY_OPENER = None
        return ""


def _load_proxy_ini():
    try:
        import configparser
        cp = configparser.ConfigParser()
        cp.read(INI_PATH, encoding="utf-8")
        return cp.get("proxy", "url", fallback="")
    except Exception:
        return ""


set_proxy(_load_proxy_ini())    # 导入即生效（GUI/CLI通用）


def _http_get(url, retries=3, timeout=15, decode="utf-8", headers=None):
    last = None
    hdr = {"User-Agent": "Mozilla/5.0"}
    if headers:
        hdr.update(headers)
    for a in range(retries):
        with _THROTTLE_LOCK:
            wait = _MIN_INTERVAL - (time.time() - _LAST_REQ[0])
            if wait > 0:
                time.sleep(wait)
            _LAST_REQ[0] = time.time()
        try:
            req = urllib.request.Request(url, headers=hdr)
            opener = _PROXY_OPENER
            if opener is not None:
                with opener.open(req, timeout=timeout) as r:
                    return r.read().decode(decode, errors="ignore")
            else:
                with urllib.request.urlopen(req, timeout=timeout) as r:
                    return r.read().decode(decode, errors="ignore")
        except Exception as e:
            last = e
            time.sleep(0.5 * (a + 1))
    raise RuntimeError(f"网络请求失败: {last}")


# ================= 交易日辅助 =================

def _dstr(d):
    return d.strftime("%Y-%m-%d")


def _prev_weekday(d):
    import datetime
    d -= datetime.timedelta(days=1)
    while d.weekday() >= 5:
        d -= datetime.timedelta(days=1)
    return d


def last_completed_td():
    """库中最后一天日K应为的日期 = 今天之前的最近工作日。
    注意：今日bar永远不入库（盘中未收盘，由实时快照在analyze里合成），
    所以即使已收盘，新鲜度基准也是上一个工作日。"""
    import datetime
    return _dstr(_prev_weekday(datetime.date.today()))


# ================= 日K增量缓存 =================

def _db_rows(conn, code):
    rows = conn.execute(
        "SELECT date,open,high,low,close,vol FROM daily_bars "
        "WHERE code=? ORDER BY date", (code,)).fetchall()
    return [{"date": r[0], "open": r[1], "high": r[2], "low": r[3],
             "close": r[4], "vol": r[5] or 0.0} for r in rows]


# ================= 多源日K获取 =================

def _code_to_163(full):
    """腾讯代码 → 网易163代码：sh600519 → 0600519, sz002241 → 1002241"""
    if full.startswith("sh"):
        return "0" + full[2:]
    if full.startswith("sz"):
        return "1" + full[2:]
    return None


def _code_to_em(full):
    """腾讯代码 → 东财代码：sh600519 → 1.600519, sz002241 → 0.002241"""
    if full.startswith("sh"):
        return "1." + full[2:]
    if full.startswith("sz"):
        return "0." + full[2:]
    return None


def _fetch_tencent(full, count=600):
    """腾讯K线（原接口，IP可能被限流）"""
    txt = _http_get(KLINE_URL + f"?param={full},day,,,{count},qfq",
                   decode="utf-8", retries=1, timeout=8)
    kd = json.loads(txt)
    d = (kd.get("data") or {}).get(full) or {}
    bars = d.get("qfqday") or d.get("day") or []
    out = []
    for b in bars:
        try:
            if float(b[2]) <= 0:
                continue
            out.append({"date": b[0], "open": float(b[1]),
                        "close": float(b[2]), "high": float(b[3]),
                        "low": float(b[4]), "vol": float(b[5])})
        except (ValueError, IndexError):
            continue
    return out


def _fetch_163(full, count=600):
    """网易163财经（免费，稳定性好，返回CSV）"""
    code163 = _code_to_163(full)
    if not code163:
        return []
    import datetime
    end = datetime.date.today().strftime("%Y%m%d")
    start = (datetime.date.today() - datetime.timedelta(days=count * 2)
             ).strftime("%Y%m%d")
    url = (f"http://quotes.money.163.com/service/chddata.html"
           f"?code={code163}&start={start}&end={end}"
           f"&fields=TCLOSE;HIGH;LOW;TOPEN;VOTURNOVER")
    txt = _http_get(url, retries=2, timeout=15, decode="gbk")
    out = []
    for line in txt.strip().split("\n"):
        if not line.strip() or line.startswith("日期"):
            continue
        parts = line.strip().split(",")
        if len(parts) < 7:
            continue
        try:
            date = parts[0].strip().strip("'")
            close = float(parts[3]) if parts[3].strip() else 0
            high = float(parts[4]) if parts[4].strip() else 0
            low = float(parts[5]) if parts[5].strip() else 0
            opn = float(parts[6]) if parts[6].strip() else 0
            vol = float(parts[11]) if len(parts) > 11 and parts[11].strip() else 0
            if close <= 0:
                continue
            out.append({"date": date, "open": opn, "close": close,
                        "high": high, "low": low, "vol": vol})
        except (ValueError, IndexError):
            continue
    out.reverse()  # 网易返回倒序，翻转
    return out[:count]


def _fetch_eastmoney(full, count=600):
    """东方财富K线（免费，JSON格式）"""
    secid = _code_to_em(full)
    if not secid:
        return []
    url = (f"https://push2his.eastmoney.com/api/qt/stock/kline/get"
           f"?secid={secid}&fields1=f1,f2,f3"
           f"&fields2=f51,f52,f53,f54,f55,f56"
           f"&klt=101&fqt=1&beg=0&end=20500101&lmt={count}")
    txt = _http_get(url, retries=2, timeout=15,
                   headers={"Referer": "https://quote.eastmoney.com/"})
    kd = json.loads(txt)
    klines = (kd.get("data") or {}).get("klines") or []
    out = []
    for line in klines:
        parts = line.split(",")
        if len(parts) < 6:
            continue
        try:
            close = float(parts[2])
            if close <= 0:
                continue
            out.append({"date": parts[0], "open": float(parts[1]),
                        "close": close, "high": float(parts[3]),
                        "low": float(parts[4]), "vol": float(parts[5])})
        except (ValueError, IndexError):
            continue
    return out[:count]


def _fetch_sina(full, count=600):
    """新浪财经K线（免费，稳定，返回JSON）"""
    url = (f"https://money.finance.sina.com.cn/quotes_service/api/"
           f"json_v2.php/CN_MarketData.getKLineData"
           f"?symbol={full}&scale=240&ma=no&datalen={count}")
    txt = _http_get(url, retries=2, timeout=15, decode="utf-8",
                   headers={"Referer": "https://finance.sina.com.cn/"})
    # 新浪返回的不是标准JSON（key没引号），做简单修复
    import re
    txt = re.sub(r'(?<=[{,])(\w+):', r'"\1":', txt)
    bars = json.loads(txt)
    out = []
    for b in bars:
        try:
            close = float(b.get("close", 0))
            if close <= 0:
                continue
            out.append({"date": b["day"], "open": float(b["open"]),
                        "close": close, "high": float(b["high"]),
                        "low": float(b["low"]),
                        "vol": float(b.get("volume", 0))})
        except (ValueError, KeyError):
            continue
    return out


def _fetch_remote_rows(full, count=600):
    """多源自动切换：腾讯 → 东财 → 网易163 → 新浪，哪个通哪个。"""
    sources = [
        ("腾讯", lambda: _fetch_tencent(full, count)),
        ("东财", lambda: _fetch_eastmoney(full, count)),
        ("网易163", lambda: _fetch_163(full, count)),
        ("新浪", lambda: _fetch_sina(full, count)),
    ]
    last_err = None
    for name, fetcher in sources:
        try:
            rows = fetcher()
            if rows and len(rows) >= 20:
                return rows
        except Exception as e:
            last_err = e
            continue
    raise RuntimeError(f"所有数据源均失败: {last_err}")


FAIL_TTL = 3600                 # 拉取失败记忆期1小时
_MIN_INTERVAL = 0.16            # 全局HTTP最小间隔，防腾讯限速
_THROTTLE_LOCK = threading.Lock()
_LAST_REQ = [0.0]


def get_daily(full, min_bars=100):
    """带缓存的日K：本地够新直接返回，否则增量爬一次并入库。
    有缓存数据的股票永远返回缓存（即使过期），不抛异常。
    只有从未成功获取过的代码才会触发网络请求和负缓存。"""
    today = time.strftime("%Y-%m-%d")
    fresh = last_completed_td()
    conn = _cx()
    try:
        rows = _db_rows(conn, full)
        # 1) 有数据且够新 → 直接返回
        if rows and rows[-1]["date"] >= fresh:
            return rows
        # 2) 有数据但过期 → 先返回缓存，后台尝试更新（失败不影响返回）
        if rows:
            try:
                remote = _fetch_remote_rows(full)
                conn2 = _cx()
                try:
                    conn2.executemany(
                        "INSERT OR REPLACE INTO daily_bars"
                        "(code,date,open,high,low,close,vol) "
                        "VALUES(?,?,?,?,?,?,?)",
                        [(full, r["date"], r["open"], r["high"], r["low"],
                          r["close"], r["vol"])
                         for r in remote if r["date"] < today])
                    conn2.commit()
                finally:
                    conn2.close()
                # 重新读取合并后的数据
                rows = _db_rows(conn, full)
            except Exception:
                pass  # 网络失败就用旧缓存，不报错
            return rows
        # 3) 无数据 → 检查负缓存
        frow = conn.execute("SELECT ts FROM failed WHERE code=?",
                            (full,)).fetchone()
        if frow and time.time() - frow[0] < FAIL_TTL:
            raise RuntimeError(f"{full} 近期拉取失败(负缓存中)")
    finally:
        conn.close()

    # 4) 从未获取过 → 网络请求
    try:
        remote = _fetch_remote_rows(full)
    except Exception:
        conn = _cx()
        try:
            conn.execute("INSERT OR REPLACE INTO failed(code,ts) VALUES(?,?)",
                         (full, time.time()))
            conn.commit()
        finally:
            conn.close()
        raise
    conn = _cx()
    try:
        conn.execute("DELETE FROM failed WHERE code=?", (full,))
        conn.executemany(
            "INSERT OR REPLACE INTO daily_bars"
            "(code,date,open,high,low,close,vol) VALUES(?,?,?,?,?,?,?)",
            [(full, r["date"], r["open"], r["high"], r["low"],
              r["close"], r["vol"]) for r in remote if r["date"] < today])
        conn.commit()
        rows = [r for r in _db_rows(conn, full)]
    finally:
        conn.close()
    return rows


def prefetch(codes, workers=6, progress=None):
    """并发预取一批代码的日K入库（首次回填用）。"""
    # 先排除已知失败的代码（10分钟内不再重试）
    conn = _cx()
    try:
        now = time.time()
        failed = {r[0] for r in
                  conn.execute("SELECT code FROM failed WHERE ts > ?",
                               (now - FAIL_TTL,)).fetchall()}
    finally:
        conn.close()
    codes = [c for c in codes if c not in failed]
    if failed and progress:
        progress(f"跳过{len(failed)}个近期失败代码")
    done = [0]
    total = len(codes)
    if total == 0:
        return

    def one(c):
        try:
            get_daily(c)
        except Exception:
            pass
        done[0] += 1
        if progress and done[0] % 10 == 0:
            progress(f"缓存回填 {done[0]}/{total}")

    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(one, codes))


# ================= 全市场代码表 / 分层 =================

def stocks_age():
    conn = _cx()
    try:
        ts = _get_meta(conn, "stocks_updated")
        if not ts:
            return 1e18
        try:
            return time.time() - float(ts)
        except ValueError:
            return 1e18
    finally:
        conn.close()


def refresh_all_codes(progress=None):
    """拉取全A代码表（代码/名称/总市值/东财行业），按市值三分位分层。"""
    with REFRESH_LOCK:
        if stocks_age() < STOCKS_TTL:
            if progress:
                progress("代码表仍新鲜，跳过")
            return False
        # 不含北交所(m:0+t:81)，腾讯K线不支持且用户不需要
        fs = "m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23"
        hosts = ("https://push2delay.eastmoney.com",
                 "https://push2.eastmoney.com",
                 "http://push2.eastmoney.com")
        items = []
        pn = 1
        while pn <= 90:
            u = (f"{hosts[(pn - 1) % len(hosts)]}/api/qt/clist/get"
                 f"?pn={pn}&pz=100&po=1&np=1&fltt=2&invariant=0"
                 f"&fields=f12,f14,f20,f100&fs={fs}&ut={UT}")
            got = False
            for host in hosts:
                uu = u.replace(u.split("/api/")[0], host)
                try:
                    data = json.loads(_http_get(
                        uu, retries=3, timeout=20,
                        headers={"Referer":
                                 "https://quote.eastmoney.com/"})
                    ).get("data") or {}
                    got = True
                    break
                except Exception:
                    time.sleep(1.5)
            if not got:
                if len(items) >= 500 or pn > 1:
                    break           # 已拿到足够数据，容忍个别页失败
                raise RuntimeError("代码表首页拉取失败")
            diff = data.get("diff") or {}
            batch = list(diff.values()) if isinstance(diff, dict) else diff
            if not batch:
                break
            for it in batch:
                code, name = it.get("f12"), it.get("f14")
                cap = it.get("f20")
                ind = it.get("f100")
                if not code or len(code) != 6 or not isinstance(cap, (int, float)):
                    continue
                if code.startswith(("4", "8", "92")):
                    full = "bj" + code
                elif code[0] in "69" or code[:2] in ("51", "56", "58"):
                    full = "sh" + code
                else:
                    full = "sz" + code
                items.append((full, name or "", ind if isinstance(ind, str) else None,
                              float(cap)))
            if progress:
                progress(f"代码表 {len(items)} 只 (第{pn}页)")
            pn += 1
            time.sleep(0.6)
        if len(items) < 500:
            raise RuntimeError(f"代码表异常: 仅{len(items)}只")

        # 市值三分位分层
        caps = sorted(it[3] for it in items)
        q1, q2 = caps[len(caps) // 3], caps[2 * len(caps) // 3]

        def tier_of(cap):
            if cap >= q2:
                return TIERS[0]
            if cap >= q1:
                return TIERS[1]
            return TIERS[2]

        today = time.strftime("%Y-%m-%d")
        conn = _cx()
        try:
            conn.execute("DELETE FROM stocks")
            conn.executemany(
                "INSERT OR REPLACE INTO stocks"
                "(code,name,industry,mktcap,tier,updated) "
                "VALUES(?,?,?,?,?,?)",
                [(c, n, i, cap, tier_of(cap), today)
                 for c, n, i, cap in items])
            _set_meta(conn, "stocks_updated", repr(time.time()))
            conn.commit()
        finally:
            conn.close()
        if progress:
            progress(f"代码表完成: {len(items)}只, 分界 "
                     f"{q1/1e8:.0f}/{q2/1e8:.0f}亿")
        return True


def ensure_codes(progress=None):
    """代码表过期则自动刷新。"""
    if stocks_age() >= STOCKS_TTL:
        try:
            refresh_all_codes(progress)
        except Exception:
            if stocks_age() >= STOCKS_TTL * 4:
                raise           # 完全没有可用代码表时才向上抛


def get_stock_info(full):
    conn = _cx()
    try:
        row = conn.execute(
            "SELECT name,industry,mktcap,tier FROM stocks WHERE code=?",
            (full,)).fetchone()
        return {"name": row[0], "industry": row[1],
                "mktcap": row[2], "tier": row[3]} if row else None
    finally:
        conn.close()


def industry_peers(full, limit=L2_DEFAULT_N):
    """L2池：同行业、市值最接近目标股的 N 只（不含自身）。"""
    info = get_stock_info(full)
    if not info or not info.get("industry"):
        return [], None
    conn = _cx()
    try:
        rows = conn.execute(
            "SELECT code,name,mktcap FROM stocks "
            "WHERE industry=? AND code!=? AND code NOT LIKE 'bj%'",
            (info["industry"], full)).fetchall()
    finally:
        conn.close()
    if not rows:
        return [], info["industry"]
    my_cap = info.get("mktcap") or 0.0
    lg = math.log(max(my_cap, 1e8))

    def near(r):
        return abs(math.log(max(r[2] or 1e8, 1e8)) - lg)

    rows.sort(key=near)
    return [r[0] for r in rows[:limit]], info["industry"]


def tier_sample(full, n=L3_DEFAULT_N, exclude_industries=()):
    """L3池：同市值层随机抽样（按日期做种子，同一天结果稳定），
    排除自身与 L2 已覆盖的行业。"""
    info = get_stock_info(full)
    if not info or not info.get("tier"):
        return [], None
    conn = _cx()
    try:
        q = ("SELECT code FROM stocks "
             "WHERE tier=? AND code!=? AND code NOT LIKE 'bj%'")
        args = [info["tier"], full]
        if exclude_industries and info.get("industry"):
            q += " AND (industry IS NULL OR industry!=?)"
            args.append(info["industry"])
        rows = [r[0] for r in conn.execute(q, args).fetchall()]
    finally:
        conn.close()
    rnd = random.Random(time.strftime("%Y%m%d") + full)
    rnd.shuffle(rows)
    return rows[:n], info["tier"]


def pool_codes(full, l2_n=L2_DEFAULT_N, l3_n=L3_DEFAULT_N):
    """一次拿到两级样本池。"""
    peers, industry = industry_peers(full, l2_n)
    l3, tier = tier_sample(full, l3_n, exclude_industries=(industry,))
    seen = {full}
    l3 = [c for c in l3 if c not in seen and not seen.add(c)]
    return {"l2": peers, "l3": l3,
            "industry": industry, "tier": tier}


QT_URL = "https://qt.gtimg.cn/q="
KLINE_URL = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"
INI_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stock_gui.ini")
AUTHOR = "獨白"
AUTHOR_EMAIL = "kingrux106@gmail.com"
AUTHOR_QQ = "2180287399"
DISCLAIMER = ("免责声明：本程序所有输出仅为历史数据的技术统计与研究用途，"
              "不构成任何投资建议或收益承诺。股市有风险，据此操作盈亏自负。")
INDEX_CODES = [
    ("sh000001", "上证指数"),
    ("sz399001", "深证成指"),
    ("sz399006", "创业板指"),
    ("sh000688", "科创50"),
    ("bj899050", "北证50"),
]

UP, DOWN, PRED_C = "#ff5252", "#26c281", "#4da3ff"
TPRED_C = "#ffffff"   # 暗色主题下白色虚线；亮色主题自动切换为黑色
MA_COLORS = {5: "#ffa94d", 10: "#74c0fc", 20: "#e599f7", 30: "#69db7c", 60: "#d5a021"}
BG = "#14181e"
GRID_C = "#232b34"
GUIDE_C = "#39434e"
AXIS_TXT = "#8fa0ad"
TITLE_TXT = "#aebccb"
CROSS_C = "#9fb3c8"
DARK_BG = "#101418"
PANEL_BG = "#171c22"
FIELD_BG = "#1c232b"
FG_MAIN = "#d7dee6"

# ---- 可切换主题 ----
THEMES = {
    "dark": dict(
        UP="#ff5252", DOWN="#26c281", PRED_C="#4da3ff", TPRED_C="#ffffff",
        BG="#14181e", GRID_C="#232b34", GUIDE_C="#39434e",
        AXIS_TXT="#8fa0ad", TITLE_TXT="#aebccb", CROSS_C="#9fb3c8",
        DARK_BG="#101418", PANEL_BG="#171c22", FIELD_BG="#1c232b",
        FG_MAIN="#d7dee6",
        BTN_BG="#222a33", BTN_FG="#d7dee6", BTN_HOVER="#2b3540",
        BTN_BORDER="#333e4a",
    ),
    "light": dict(
        UP="#e03131", DOWN="#0ca678", PRED_C="#1971c2", TPRED_C="#111111",
        BG="#ffffff", GRID_C="#ececec", GUIDE_C="#f1f3f5",
        AXIS_TXT="#777777", TITLE_TXT="#444444", CROSS_C="#999999",
        DARK_BG="#f2f4f7", PANEL_BG="#ffffff", FIELD_BG="#ffffff",
        FG_MAIN="#1f2933",
        BTN_BG="#ffffff", BTN_FG="#1f2933", BTN_HOVER="#eef1f4",
        BTN_BORDER="#bbbbbb",
    ),
}


def apply_theme(theme, updown):
    """按设置重写模块级颜色常量；绘图函数读取全局值。"""
    t = dict(THEMES.get(theme, THEMES["dark"]))
    if updown == "green_up":
        t["UP"], t["DOWN"] = t["DOWN"], t["UP"]
    for k, v in t.items():
        globals()[k] = v


# ================= 数据获取 =================

def http_get(url, retries=3):
    last = None
    for a in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=15) as r:
                return r.read().decode("gbk", errors="ignore")
        except Exception as e:
            last = e
            time.sleep(1.5 * (a + 1))
    raise RuntimeError(f"网络请求失败: {last}")


def normalize_code(code):
    code = code.strip().lower()
    for p in ("sh", "sz", "bj"):
        if code.startswith(p):
            return p + code[2:]
    d = "".join(ch for ch in code if ch.isdigit())
    if len(d) != 6:
        raise ValueError(f"代码格式不对: {code}")
    if d[0] in "69" or d[:2] in ("51", "56", "58"):      # 沪股/沪ETF
        return "sh" + d
    if d[0] in "03" or d[:2] in ("15", "16", "18"):      # 深股/深ETF/LOF
        return "sz" + d
    if d[0] in "48":
        return "bj" + d
    raise ValueError(f"不支持的代码: {code}")


def vol_ratio_at(vols, i):
    """截至第 i 日（含）的量能状态：近5日均量 / 前15日均量。"""
    if i < 19:
        return None
    r5 = sum(vols[i - 4:i + 1]) / 5
    p15 = sum(vols[i - 19:i - 4]) / 15
    return (r5 / p15) if p15 > 0 else None


def vol_regime(vr):
    if vr is None:
        return "?"
    if vr > 1.2:
        return "放量"
    if vr < 0.8:
        return "缩量"
    return "平量"


def fmt_vol_cn(v):
    if v >= 1e8:
        return f"{v/1e8:.2f}亿"
    if v >= 1e4:
        return f"{v/1e4:.1f}万"
    return f"{v:.0f}"


_SECTOR_CACHE = {}          # code -> (timestamp, 结果三元组)
_SECTOR_CACHE_TTL = 1800    # 30 分钟
_BK_LIST_CACHE = {}         # 板块名 -> BK代码（全局，行业名单变化慢）
_BK_LIST_TS = 0.0


def fetch_sector_context(full):
    """个股所属行业板块指数上下文。

    返回 (板块名, {date: 当日涨跌%}, 板块今日涨跌%)；失败返回 (None, {}, None)。
    带 30 分钟缓存：板块日内变化不大，命中缓存零耗时。
    """
    now = time.time()
    hit = _SECTOR_CACHE.get(full)
    if hit and now - hit[0] < _SECTOR_CACHE_TTL:
        return hit[1]
    UT = "fa5fd1943c7b386f172d6893dbfba10b"
    hdr = {"User-Agent": "Mozilla/5.0",
           "Referer": "https://quote.eastmoney.com/"}

    def get(u, timeout=4):
        last = None
        hosts = ("https://push2.eastmoney.com",
                 "https://push2delay.eastmoney.com")
        for host in hosts:
            uu = u.replace("https://push2.eastmoney.com", host)
            for a in range(1):
                try:
                    req = urllib.request.Request(uu, headers=hdr)
                    with urllib.request.urlopen(req, timeout=timeout) as r:
                        return r.read().decode("utf-8")
                except Exception as e:
                    last = e
        raise last

    try:
        global _BK_LIST_CACHE, _BK_LIST_TS
        code = full[2:]
        mkt = "1" if full.startswith("sh") else "0"
        # 1) 个股行业名
        u = (f"https://push2.eastmoney.com/api/qt/stock/get"
             f"?secid={mkt}.{code}&fields=f127&ut={UT}")
        ind_name = json.loads(get(u))["data"].get("f127")
        if not ind_name:
            return None, {}, None
        # 2) 行业板块列表（分页，全局缓存 30 分钟），按名称匹配 BK 代码
        bk_code = None
        if _BK_LIST_CACHE and now - _BK_LIST_TS < _SECTOR_CACHE_TTL:
            bk_code = _BK_LIST_CACHE.get(ind_name)
        else:
            _BK_LIST_CACHE = {}
            for pn in (1, 2, 3):
                u = (f"https://push2.eastmoney.com/api/qt/clist/get"
                     f"?pn={pn}&pz=100&po=1&np=1&fltt=2&invariant=0"
                     f"&fields=f12,f14&fs=m:90+t:2&ut={UT}")
                diff = json.loads(get(u)).get("data", {}).get("diff") or {}
                items = list(diff.values()) if isinstance(diff, dict) else diff
                for it in items:
                    _BK_LIST_CACHE[it.get("f14")] = it.get("f12")
                if len(items) < 100:
                    break
            _BK_LIST_TS = now
            bk_code = _BK_LIST_CACHE.get(ind_name)
        if not bk_code:
            return ind_name, {}, None
        # 3) 板块日K（收盘价）
        u = (f"https://push2his.eastmoney.com/api/qt/stock/kline/get"
             f"?secid=90.{bk_code}&fields1=f1,f2,f3&fields2=f51,f53"
             f"&klt=101&fqt=0&beg=20240101&end=20500101")
        kl = json.loads(get(u, timeout=8))["data"]["klines"]
        bars = [(s.split(",")[0], float(s.split(",")[1])) for s in kl]
        chg_by_date = {
            b[0]: (b[1] / a[1]) * 100 - 100
            for a, b in zip(bars, bars[1:])
        }
        today_chg = chg_by_date.get(bars[-1][0])
        return ind_name, chg_by_date, today_chg
    except Exception:
        return None, {}, None


def fetch_quote(full):
    f = http_get(QT_URL + full).split("~")
    if len(f) < 35 or not f[3]:
        raise ValueError("未查询到该股票")
    return {"name": f[1], "price": float(f[3]), "prev_close": float(f[4]),
            "open": float(f[5]), "high": float(f[33]), "low": float(f[34]),
            "time": f[30]}


def fetch_daily(full):
    kd = json.loads(http_get(KLINE_URL + f"?param={full},day,,,500,qfq"))
    d = kd.get("data", {}).get(full)
    if not d:
        raise ValueError("K线数据获取失败")
    bars = d.get("qfqday") or d.get("day")
    rows = [{"date": b[0], "open": float(b[1]), "close": float(b[2]),
             "high": float(b[3]), "low": float(b[4]), "vol": float(b[5])}
            for b in bars if float(b[2]) > 0]
    if len(rows) < 100:
        raise ValueError("上市时间太短，样本不足")
    return rows


# ================= 指标计算 =================

def sma_period(vals, n):
    out = [None] * len(vals)
    s = 0.0
    for i, v in enumerate(vals):
        s += v
        if i >= n:
            s -= vals[i - n]
        if i >= n - 1:
            out[i] = s / n
    return out


def ema(vals, n):
    out, k, e = [], 2 / (n + 1), None
    for v in vals:
        e = v if e is None else v * k + e * (1 - k)
        out.append(e)
    return out


def calc_macd(closes):
    dif = [a - b for a, b in zip(ema(closes, 12), ema(closes, 26))]
    dea_raw = ema(dif, 9)
    dea = [None] * 8 + dea_raw[8:]
    hist = [None if dd is None else 2 * (a - dd) for a, dd in zip(dif, dea)]
    return dif, dea, hist


def calc_kdj(rows, n=9):
    ks, ds = [], []
    k = d = 50.0
    for i in range(len(rows)):
        seg = rows[max(0, i - n + 1):i + 1]
        lo = min(r["low"] for r in seg)
        hi = max(r["high"] for r in seg)
        rsv = (rows[i]["close"] - lo) / (hi - lo) * 100 if hi > lo else 50.0
        k = k * 2 / 3 + rsv / 3
        d = d * 2 / 3 + k / 3
        ks.append(k)
        ds.append(d)
    return ks, ds, [3 * a - 2 * b for a, b in zip(ks, ds)]


def calc_rsi(closes, n):
    out = [None] * len(closes)
    if len(closes) <= n:
        return out
    gains = [max(closes[i] - closes[i - 1], 0) for i in range(1, len(closes))]
    losses = [max(closes[i - 1] - closes[i], 0) for i in range(1, len(closes))]
    ag, al = sum(gains[:n]) / n, sum(losses[:n]) / n
    out[n] = 100.0 if al == 0 else 100 - 100 / (1 + ag / al)
    for i in range(n + 1, len(closes)):
        ag = (ag * (n - 1) + gains[i - 1]) / n
        al = (al * (n - 1) + losses[i - 1]) / n
        out[i] = 100.0 if al == 0 else 100 - 100 / (1 + ag / al)
    return out


def pct(vals, p):
    s = sorted(vals)
    k = (len(s) - 1) * p / 100
    lo, hi = int(k), min(int(k) + 1, len(s) - 1)
    f = k - lo
    return s[lo] * (1 - f) + s[hi] * f


def znorm(win):
    m = sum(win) / len(win)
    sd = (sum((x - m) ** 2 for x in win) / len(win)) ** 0.5 or 1e-12
    return [(x - m) / sd for x in win]


def logret(seq):
    return [math.log(seq[i + 1] / seq[i]) for i in range(len(seq) - 1)]


W_WINDOW, TOPK = 10, 10

# ---- 三级样本池：L1自身 / L2同行业 / L3同市值层，融合权重 ----
LV_W = {"L1": 0.6, "L2": 0.3, "L3": 0.1}
LV_LABEL = {"L1": "自身历史", "L2": "同行业", "L3": "同市值层"}


def wpct(pairs, p):
    """加权分位数：pairs=[(值,权重)]，p∈{10..90}。"""
    pairs = sorted(pairs)
    tot = sum(w for _, w in pairs) or 1.0
    acc = 0.0
    for v, w in pairs:
        acc += w
        if acc >= p / 100 * tot:
            return v
    return pairs[-1][0]


def _pool_match(pool_rows, cur, vr_now, idx_chg_by_date, idx_chg_today,
                topk=TOPK):
    """在多只股票的日K池里跑与 L1 相同的窗口匹配，返回样本列表。

    pool_rows: [(code, rows)]；评分 = 形态距离 + 量能项 + 大盘环境项。
    """
    W = W_WINDOW
    info = {}
    sims = []
    for code, rows in pool_rows:
        closes = [r["close"] for r in rows]
        rets = logret(closes)
        if len(rets) < W + 3:
            continue
        vols = [r.get("vol") or 0.0 for r in rows]
        vr_arr = [vol_ratio_at(vols, k) for k in range(len(vols))]
        info[code] = (rows, vr_arr)
        for i in range(W, len(rets) - 1):
            w = znorm(rets[i - W:i])
            d_px = sum((a - b) ** 2 for a, b in zip(cur, w)) ** 0.5
            vr_i = vr_arr[i]
            if vr_now is not None and vr_i is not None:
                d_v = abs(math.log(max(vr_now, 1e-6) / max(vr_i, 1e-6)))
                s_v = 0.6 * min(d_v, 2.5)
            else:
                s_v = 0.30
            ic = idx_chg_by_date.get(rows[i]["date"])
            if ic is not None and idx_chg_today is not None:
                s_i = min(1.5, 0.3 * abs(ic - idx_chg_today))
            else:
                s_i = 0.40
            sims.append((d_px + s_v + s_i, i, code))
    if not info:
        return []
    top = heapq.nsmallest(topk, sims, key=lambda x: x[0])
    out = []
    for score, i, code in top:
        rows, vr_arr = info[code]
        r, n1, n2 = rows[i], rows[i + 1], rows[i + 2]
        ic = idx_chg_by_date.get(r["date"])
        out.append({
            "t_date": r["date"], "n1_date": n1["date"], "n2_date": n2["date"],
            "vr": vr_arr[i],
            "idx_chg": (ic - idx_chg_today
                        if (ic is not None and idx_chg_today is not None)
                        else None),
            "gap": n1["open"] / r["close"] - 1,
            "hi_o": n1["high"] / n1["open"] - 1,
            "lo_o": n1["low"] / n1["open"] - 1,
            "cl_o": n1["close"] / n1["open"] - 1,
            "t2_gap": n2["open"] / n1["close"] - 1,
            "t2_hi": n2["high"] / n2["open"] - 1,
            "t2_lo": n2["low"] / n2["open"] - 1,
            "t2_cl": n2["close"] / n2["open"] - 1,
            "code": code,
        })
    return out


def market_phase_text(time_str):
    """行情快照时间(YYYYMMDDHHMMSS...) -> 'HH:MM 市场阶段'。"""
    try:
        hhmm = int((time_str or "")[8:12])
    except ValueError:
        return "时间未知"
    hm = f"{hhmm // 100}:{hhmm % 100:02d}"
    if hhmm < 915:
        return hm + " 盘前"
    if hhmm < 925:
        return hm + " 集合竞价"
    if hhmm < 1130 or 1300 <= hhmm < 1500:
        return hm + " 盘中交易"
    if hhmm < 1300:
        return hm + " 午间休市"
    return hm + " 已收盘"


def _load_pools(pool_info, cur, vr_now, idx_chg_by_date, idx_chg_today,
                progress=None):
    """取 L2/L3 池K线（走缓存增量）并跑匹配，返回 {"L2":[...], "L3":[...]}。"""
    out = {}
    for key in ("L2", "L3"):
        codes = pool_info.get(key.lower()) or []
        if not codes:
            continue
        try:
            if progress:
                progress(f"回填{LV_LABEL[key]}池 {len(codes)}只(仅首次)...")
            prefetch(codes, workers=10,
                        progress=progress if progress else None)
            pool_rows = []
            for c in codes:
                try:
                    r = get_daily(c)
                    if len(r) >= 130:
                        pool_rows.append((c, r))
                except Exception:
                    continue
            smp = _pool_match(pool_rows, cur, vr_now, idx_chg_by_date,
                              idx_chg_today)
            if smp:
                out[key] = smp
        except Exception:
            continue
    return out


# ================= 分析 =================

def analyze(full, progress=None, sector_only=False):
    """全量分析，切片交给GUI。sector_only=True 时仅加载L2同板块池。"""
    W = W_WINDOW
    # ---- 并发拉取全部数据源（个股行情/K线、上证行情/K线、板块、样本池）----
    now_ts = time.time()
    sec_cached = _SECTOR_CACHE.get(full)
    sec_hit = bool(sec_cached and now_ts - sec_cached[0] < _SECTOR_CACHE_TTL)
    with ThreadPoolExecutor(max_workers=5 if not sec_hit else 4) as ex:
        f_q = ex.submit(fetch_quote, full)
        if CACHE_OK:
            f_rows = ex.submit(get_daily, full)
        else:
            f_rows = ex.submit(fetch_daily, full)
        f_iq = ex.submit(fetch_quote, "sh000001")
        if CACHE_OK:
            f_ir = ex.submit(get_daily, "sh000001")
        else:
            f_ir = ex.submit(fetch_daily, "sh000001")
        f_sec = None if sec_hit else ex.submit(fetch_sector_context, full)
        pool_info = None
        if CACHE_OK and stocks_age() < STOCKS_TTL * 4:
            try:
                _l3n = 0 if sector_only else L3_DEFAULT_N
                pool_info = ex.submit(pool_codes, full,
                                      L2_DEFAULT_N, _l3n).result(timeout=15)
            except Exception:
                pool_info = None
        q = f_q.result()
        rows = f_rows.result()

        # 识别今日盘中bar（缓存库只存已收盘日K，实时bar由快照合成）
        today_str = time.strftime("%Y-%m-%d")
        today_compact = today_str.replace("-", "")
        live = None
        snap_full = (q.get("time") or "")
        snap_d = snap_full[:8]
        try:
            hhmm = int(snap_full[8:12])
        except ValueError:
            hhmm = 0
        if (snap_d == today_compact and q["price"] > 0 and hhmm >= 925):
            pc0 = q["prev_close"] or (rows[-1]["close"] if rows else 0)
            lo0 = q["low"] if q["low"] > 0 else min(q["price"], q["open"] or q["price"])
            live = {"date": today_str, "open": q["open"] or pc0,
                    "close": q["price"],
                    "high": max(q["high"], q["price"]),
                    "low": min(lo0, q["price"]), "vol": 0.0}
        had_today_bar = live is not None
        if len(rows) < 100:
            raise ValueError("上市时间太短，样本不足")

        try:
            iq = f_iq.result()
            idx_chg_today = ((iq["price"] / iq["prev_close"]) * 100 - 100
                             if iq["prev_close"] else 0.0)
        except Exception:
            idx_chg_today = None
        try:
            idx_rows = f_ir.result()
            idx_chg_by_date = {
                b["date"]: (b["close"] / a["close"]) * 100 - 100
                for a, b in zip(idx_rows, idx_rows[1:])
            }
        except Exception:
            idx_chg_by_date = {}
        try:
            if sec_hit:
                sec_name, sec_chg_by_date, sec_chg_today = sec_cached[1]
            else:
                sec_name, sec_chg_by_date, sec_chg_today = f_sec.result(
                    timeout=8)
                if sec_name:
                    _SECTOR_CACHE[full] = (
                        time.time(),
                        (sec_name, sec_chg_by_date, sec_chg_today))
        except Exception:
            sec_name, sec_chg_by_date, sec_chg_today = None, {}, None

    closes_m = [r["close"] for r in rows]
    rets = logret(closes_m)

    vols_m = [r.get("vol") or 0.0 for r in rows]
    vr_arr = [vol_ratio_at(vols_m, k) for k in range(len(vols_m))]
    vr_now = vr_arr[-1]
    cur_regime = vol_regime(vr_now)

    def _dist_vol(i):
        vr_i = vr_arr[i]
        if vr_now is None or vr_i is None:
            return None
        return abs(math.log(max(vr_now, 1e-6) / max(vr_i, 1e-6)))

    def _dist_idx(i):
        ic = idx_chg_by_date.get(rows[i]["date"])
        if ic is None or idx_chg_today is None:
            return None
        return abs(ic - idx_chg_today)          # 百分点差

    def _dist_sec(i):
        sc = sec_chg_by_date.get(rows[i]["date"])
        if sc is None or sec_chg_today is None:
            return None
        return abs(sc - sec_chg_today)

    cur = znorm(rets[-W:])
    sims = []
    for i in range(W, len(rets) - 1):
        w = znorm(rets[i - W:i])
        d_px = sum((a - b) ** 2 for a, b in zip(cur, w)) ** 0.5
        d_v = _dist_vol(i)
        d_i = _dist_idx(i)
        d_s = _dist_sec(i)
        score = (d_px
                 + (0.6 * min(d_v, 2.5) if d_v is not None else 0.30)
                 + (min(1.5, 0.3 * d_i) if d_i is not None else 0.40)
                 + (min(1.2, 0.25 * d_s) if d_s is not None else 0.30))
        sims.append((score, i))
    top = heapq.nsmallest(TOPK, sims, key=lambda x: x[0])

    prev_close = q["prev_close"] or closes_m[-1]
    # 盘前检测：快照日期已切到今日，但日K还没有今日bar → 尚未开盘，
    # 无今开可锚，改锚昨收（否则会把上一交易日的开价误当"今开"）
    snap_d = (q.get("time") or "")[:8].replace("-", "")
    today_compact = today_str.replace("-", "")
    pre_open = (not had_today_bar
                and snap_d >= today_compact)
    if pre_open:
        o_today = prev_close
        anchor = "昨收(未开盘)"
    else:
        o_today = q["open"] or prev_close
        anchor = "今开"
    gap_today = (o_today / prev_close - 1) * 100

    # 市场阶段（按行情快照时间）
    phase = market_phase_text(q.get("time"))
    next_label = "今日(T)" if pre_open else "次日(T+1)"

    samples = []
    for _, i in top:
        r, n1, n2 = rows[i], rows[i + 1], rows[i + 2]
        ic = idx_chg_by_date.get(r["date"])
        sc = sec_chg_by_date.get(r["date"])
        samples.append({
            "t_date": r["date"], "n1_date": n1["date"], "n2_date": n2["date"],
            "vr": vr_arr[i],
            "idx_chg": (ic - idx_chg_today
                        if (ic is not None and idx_chg_today is not None)
                        else None),
            "sec_d": (sc - sec_chg_today
                      if (sc is not None and sec_chg_today is not None)
                      else None),
            "gap": n1["open"] / r["close"] - 1,
            "hi_o": n1["high"] / n1["open"] - 1,
            "lo_o": n1["low"] / n1["open"] - 1,
            "cl_o": n1["close"] / n1["open"] - 1,
            "t2_gap": n2["open"] / n1["close"] - 1,
            "t2_hi": n2["high"] / n2["open"] - 1,
            "t2_lo": n2["low"] / n2["open"] - 1,
            "t2_cl": n2["close"] / n2["open"] - 1,
        })
    # 样本分层筛选：① 量能状态+大盘涨跌接近 ② 开盘缺口接近 ③ 全部
    for s in samples:
        s["regime"] = vol_regime(s.get("vr"))
    sel_ctx = [
        s for s in samples
        if s["regime"] == cur_regime
        and s["idx_chg"] is not None and abs(s["idx_chg"]) <= 0.8
        and (s["sec_d"] is None or abs(s["sec_d"]) <= 1.2)
    ]
    sel_gap = [s for s in samples if abs(s["gap"] * 100 - gap_today) <= 1.0]
    if len(sel_ctx) >= 3:
        src, filter_note = sel_ctx, f"量能({cur_regime})+大盘(±0.8pp)筛选"
    elif len(sel_gap) >= 3:
        src, filter_note = sel_gap, "按开盘缺口筛选"
    else:
        src, filter_note = samples, "使用全部样本"

    # ---- 二三级样本池：L2 同行业 / L3 同市值层 ----
    level_map = {}
    pool_note = ""
    if CACHE_OK and pool_info:
        try:
            if progress:
                progress("拉取同行/同市值层K线(首次回填较慢)...")
            level_map = _load_pools(pool_info, cur, vr_now,
                                    idx_chg_by_date, idx_chg_today,
                                    progress)
            parts = [f"{LV_LABEL['L1']}{len(src)}"]
            parts += [f"{LV_LABEL[k]}{len(v)}"
                      for k, v in sorted(level_map.items()) if v]
            pool_note = "样本池: " + "+".join(parts)
        except Exception as e:
            pool_note = f"样本池不可用({e.__class__.__name__})"

    # ---- 三级加权融合：L1 0.6 / L2 0.3 / L3 0.1 ----
    levels = [("L1", src)] + [(k, v) for k, v in sorted(level_map.items())
                              if v]
    tot_w = sum(LV_W[k] for k, _ in levels)

    def _wfield(field):
        pairs = []
        for k, smp in levels:
            w = LV_W[k] / tot_w / len(smp)
            pairs.extend((s[field], w) for s in smp)
        return pairs

    PS = (10, 25, 50, 75, 90)
    t_pred = {
        "cl": {p: o_today * (1 + wpct(_wfield("cl_o"), p)) for p in PS},
        "hi": {p: o_today * (1 + wpct(_wfield("hi_o"), p)) for p in PS},
        "lo": {p: o_today * (1 + wpct(_wfield("lo_o"), p)) for p in PS},
        "up_prob": sum(LV_W[k] / tot_w
                       * len([s for s in smp if s["cl_o"] > 0]) / len(smp)
                       for k, smp in levels),
    }
    base = t_pred["cl"][50]
    # 盘中实时修正：预测区间必须包含已实现的最高/最低
    clamped = False
    if live is not None:
        clamped = True
        for pp in (10, 25, 50, 75, 90):
            t_pred["hi"][pp] = round(max(t_pred["hi"][pp], live["high"]), 2)
            t_pred["lo"][pp] = round(min(t_pred["lo"][pp], live["low"]), 2)
    pred = {"date": "T日预测" if pre_open else "T+1预测", "open": base,
            "close": base * (1 + wpct(_wfield("t2_cl"), 50)),
            "high": base * (1 + wpct(_wfield("t2_hi"), 75)),
            "low": base * (1 + wpct(_wfield("t2_lo"), 25)),
            "vol": None}

    # 指标基于 匹配历史(+今日盘中) 计算
    disp_rows = rows + ([live] if live else [])
    closes_i = [r["close"] for r in disp_rows]
    dif, dea, mhist = calc_macd(closes_i)
    k_, d_, j_ = calc_kdj(disp_rows)
    r6, r12 = calc_rsi(closes_i, 6), calc_rsi(closes_i, 12)
    mas = {n: sma_period(closes_i, n) for n in MA_COLORS}

    signals = []
    start = max(1, len(disp_rows) - 120)
    for i in range(start, len(disp_rows)):
        day = disp_rows[i]["date"]
        if None in (dif[i], dea[i], dif[i - 1], dea[i - 1]):
            continue
        if dif[i - 1] <= dea[i - 1] and dif[i] > dea[i]:
            signals.append((i, day, "BUY", f"MACD金叉 DIF={dif[i]:.3f}>DEA={dea[i]:.3f}"))
        elif dif[i - 1] >= dea[i - 1] and dif[i] < dea[i]:
            signals.append((i, day, "SELL", f"MACD死叉 DIF={dif[i]:.3f}<DEA={dea[i]:.3f}"))
        if k_[i - 1] <= d_[i - 1] and k_[i] > d_[i] and k_[i] < 45:
            signals.append((i, day, "BUY", f"KDJ低位金叉 K={k_[i]:.1f}>D={d_[i]:.1f}"))
        elif k_[i - 1] >= d_[i - 1] and k_[i] < d_[i] and k_[i] > 65:
            signals.append((i, day, "SELL", f"KDJ高位死叉 K={k_[i]:.1f}<D={d_[i]:.1f}"))
        if r6[i] is not None and r6[i - 1] is not None:
            if r6[i - 1] < 20 and r6[i] >= 20:
                signals.append((i, day, "BUY", f"RSI6超卖回升 {r6[i]:.1f}"))
            elif r6[i - 1] > 80 and r6[i] <= 80:
                signals.append((i, day, "SELL", f"RSI6超买回落 {r6[i]:.1f}"))

    # ---- 量价配合信号：放量站上/跌破 MA20（结合历史量能）----
    vols_d = [r.get("vol") or 0.0 for r in disp_rows]
    for i in range(max(21, len(disp_rows) - 120), len(disp_rows)):
        ma20, ma20p = mas[20][i], mas[20][i - 1]
        if not ma20 or not ma20p or not vols_d[i]:
            continue
        day = disp_rows[i]["date"]
        c, cp = disp_rows[i]["close"], disp_rows[i - 1]["close"]
        v5 = sum(vols_d[max(0, i - 5):i]) / max(1, min(5, i))
        vr_d = vols_d[i] / v5 if v5 > 0 else 0.0
        if cp <= ma20p and c > ma20 and vr_d > 1.2:
            signals.append((i, day, "BUY",
                            f"放量站上MA20 量比{vr_d:.1f}"))
        elif cp >= ma20p and c < ma20 and vr_d > 1.2:
            signals.append((i, day, "SELL",
                            f"放量跌破MA20 量比{vr_d:.1f}"))

    # ---- 历史形态统计信号：当日窗口在全部历史中找最相似样本，看其次日涨跌分布 ----
    stat_days = min(60, len(rows) - W - 2)
    win_cache = {}

    def zwin(i):
        if i not in win_cache:
            win_cache[i] = znorm(rets[i - W:i])
        return win_cache[i]

    stat_signals = []
    for i in range(len(rows) - stat_days, len(rows)):
        base = zwin(i)
        cands = []
        for j in range(W, i - 5):      # 仅用 i 之前的历史窗口，避免前视偏差
            wj = zwin(j)
            d0 = sum((a - b) ** 2 for a, b in zip(base, wj)) ** 0.5
            d_v = _dist_vol(j)
            sc = d0 + (0.6 * min(d_v, 2.5) if d_v is not None else 0.30)
            cands.append((sc, j))
        if not cands:
            continue
        topN = heapq.nsmallest(6, cands, key=lambda x: x[0])
        ups = tot = 0
        sret = 0.0
        for _, j in topN:
            nxt = rows[j + 1]["close"] / rows[j]["close"] - 1
            tot += 1
            sret += nxt
            if nxt > 0:
                ups += 1
        if tot == 0:
            continue
        ratio, avg = ups / tot, sret / tot * 100
        day = rows[i]["date"]
        if ratio >= 0.67 and avg > 0.2:
            stat_signals.append((i, day, "BUY",
                                 f"历史相似形态偏多 {ups}/{tot} 平均{avg:+.1f}%"))
        elif ratio <= 0.33 and avg < -0.2:
            stat_signals.append((i, day, "SELL",
                                 f"历史相似形态偏空 {tot-ups}/{tot} 平均{avg:+.1f}%"))
    signals.extend(stat_signals)
    signals.sort(key=lambda s: s[0])

    # ---- 每日去重：一天只保留一个信号，主信号按优先级选取 ----
    def _prio(txt):
        if txt.startswith("MACD"):
            return 0
        if txt.startswith("放量"):
            return 1
        if txt.startswith("历史相似形态"):
            return 2
        if txt.startswith("KDJ"):
            return 3
        if txt.startswith("RSI"):
            return 4
        return 5

    grouped = {}
    for sig in signals:
        grouped.setdefault(sig[0], []).append(sig)
    merged = []
    for i, lst in grouped.items():
        lst.sort(key=lambda s: (_prio(s[3]),))
        first = lst[0]
        extras = [s[3].split()[0] for s in lst[1:]]
        txt = first[3]
        if extras:
            txt += f"（+{'、'.join(extras)}）"
        merged.append((i, first[1], first[2], txt))
    merged.sort(key=lambda s: s[0])
    signals = merged

    vols = [r["vol"] for r in disp_rows]
    # 当日实时预测K线（仅盘中生成）：锚定今开，收/高/低均取中位数包络
    tpred_bar = None
    if live is not None:
        tpred_bar = {"date": "T日预测", "open": o_today,
                     "close": t_pred["cl"][50],
                     "high": t_pred["hi"][50], "low": t_pred["lo"][50],
                     "vol": None}
    return {
        "quote": q, "full_code": full, "disp_rows": disp_rows,
        "anchor": anchor, "pre_open": pre_open,
        "phase": phase, "next_label": next_label,
        "tpred_bar": tpred_bar,
        "pred": pred, "t_pred": t_pred, "samples": samples, "src_n": len(src),
        "filtered": src is not samples,
        "filter_note": filter_note,
        "levels": [{"key": k, "label": LV_LABEL[k], "n": len(smp),
                    "up_prob": len([s for s in smp if s["cl_o"] > 0])
                    / len(smp)} for k, smp in levels],
        "pool_note": pool_note,
        "idx_chg_today": idx_chg_today, "vr_now": vr_now,
        "cur_regime": cur_regime,
        "sector_name": sec_name, "sector_chg_today": sec_chg_today,
        "ind": {"ma": mas, "dif": dif, "dea": dea, "mhist": mhist,
                "k": k_, "d": d_, "j": j_, "rsi6": r6, "rsi12": r12},
        "vols": vols,
        "signals": signals,
        "gap_today": gap_today, "prev_close": prev_close,
        "has_live": bool(live),
        "live_high": live["high"] if live else None,
        "live_low": live["low"] if live else None,
        "clamped": clamped,
    }


def slice_view(res, show_n):
    n_total = len(res["disp_rows"])
    off = max(0, n_total - show_n)
    pd = res["pred"]["date"]
    view = {
        "bars": res["disp_rows"][off:] + [res["pred"]],
        "dates": ([r["date"] for r in res["disp_rows"][off:]]
                  + ["T+1" if pd.startswith("T+") else "T日"]),
        "off": off,
        "tpred": res.get("tpred_bar"),   # 当日预测：叠加在实时K线上
        "phase": (res.get("phase", "")
                  + (" · 预测锚定昨收" if res.get("pre_open") else "")),
        "pred_label": "T+1" if pd.startswith("T+") else "T日",
        "ma": {nn: vals[off:] for nn, vals in res["ind"]["ma"].items()},
        "dif": res["ind"]["dif"][off:], "dea": res["ind"]["dea"][off:],
        "mhist": res["ind"]["mhist"][off:],
        "k": res["ind"]["k"][off:], "d": res["ind"]["d"][off:], "j": res["ind"]["j"][off:],
        "rsi6": res["ind"]["rsi6"][off:], "rsi12": res["ind"]["rsi12"][off:],
        "vols": res["vols"][off:] + [None],
        "signals": [(i - off, dt, t, txt) for i, dt, t, txt in res["signals"] if i >= off],
    }
    return view


# ================= GUI =================

class Chart(tk.Canvas):
    def __init__(self, master, height):
        super().__init__(master, height=height, bg=BG, highlightthickness=0)


def deepseek_chat(api_key, prompt, model="deepseek-chat", timeout=90):
    """调用 DeepSeek chat 接口（纯标准库）。"""
    body = json.dumps({
        "model": model,
        "messages": [
            {"role": "system",
             "content": "你是专业A股分析师，回答简洁直接，给出可操作建议并附风险提示。"},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.3,
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.deepseek.com/chat/completions",
        data=body,
        headers={"Content-Type": "application/json",
                 "Authorization": f"Bearer {api_key}"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = e.read().decode("utf-8")[:200]
        except Exception:
            pass
        if e.code == 401:
            raise RuntimeError("API Key 无效 (401)，请在设置中检查")
        raise RuntimeError(f"HTTP {e.code}: {detail or e.reason}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"网络错误: {e.reason}")
    return d["choices"][0]["message"]["content"]


class App:
    PANEL_H = {"main": 400, "vol": 110, "ind": 160}
    REFRESH_MS = 15 * 60 * 1000     # 完整重分析间隔
    TICK_MS = 60 * 1000             # 行情快照刷新（1分钟）

    def __init__(self, root):
        self.root = root
        root.title("股票形态相似度预测工具 · 增强版")
        try:
            _sw, _sh = root.winfo_screenwidth(), root.winfo_screenheight()
            root.geometry(f"{min(_sw, 1520)}x{min(_sh, 940)}+0+0")
        except Exception:
            root.geometry("1520x940")
        self.settings = {"theme": "dark", "updown": "red_up"}
        self.api_key = ""
        self.watchlist = []
        self.ai_text = ""
        self.idx_data = {}
        self._load_config()
        apply_theme(self.settings["theme"], self.settings["updown"])
        root.configure(bg=DARK_BG)
        self._style_ttk()
        self.res = None
        self.view = None
        self.scales = {}
        self.show_n = tk.IntVar(value=60)
        self.ind_name = tk.StringVar(value="MACD")
        self.ma_on = {nn: tk.BooleanVar(value=True) for nn in MA_COLORS}

        self._build_toolbar()
        if getattr(self, "_last_code", ""):
            self.code_var.set(self._last_code)
        self._build_body()
        self._refresh_names()           # 启动即拉取自选池名称（后台）
        if CACHE_OK:
            threading.Thread(target=self._warm_cache, daemon=True).start()
        if self.code_var.get():
            self.run()
        self._update_indices()          # 立即刷新指数
        self.root.after(30000, self._index_loop)
        self.root.after(self.REFRESH_MS, self._auto_refresh)   # 15分钟完整重分析
        self.root.after(self.TICK_MS, self._tick)              # 5秒行情快照

    def _style_ttk(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(".", background=DARK_BG, foreground=FG_MAIN,
                        fieldbackground=FIELD_BG, bordercolor="#2a3340",
                        lightcolor=PANEL_BG, darkcolor="#12171d",
                        troughcolor=DARK_BG)
        style.configure("TFrame", background=DARK_BG)
        style.configure("TLabelframe", background=DARK_BG,
                        bordercolor="#2a3340")
        style.configure("TLabelframe.Label", background=DARK_BG,
                        foreground=TITLE_TXT)
        style.configure("TLabel", background=DARK_BG, foreground=FG_MAIN)
        style.configure("TButton", background=BTN_BG, foreground=BTN_FG,
                        bordercolor=BTN_BORDER)
        style.map("TButton", background=[("active", BTN_HOVER)])
        style.configure("TEntry", fieldbackground=FIELD_BG, foreground=FG_MAIN)
        style.configure("TCombobox", fieldbackground=FIELD_BG,
                        foreground=FG_MAIN, background=BTN_BG, arrowcolor=FG_MAIN)
        style.map("TCombobox",
                  fieldbackground=[("readonly", FIELD_BG)],
                  foreground=[("readonly", FG_MAIN)])
        style.configure("TScrollbar", background=BTN_BG,
                        troughcolor=DARK_BG)
        style.configure("Checkbutton", background=DARK_BG, foreground=FG_MAIN)
        style.map("Checkbutton", background=[("active", DARK_BG)])

    # ---------- 布局 ----------

    def _build_toolbar(self):
        top = ttk.Frame(self.root, padding=2)
        top.pack(fill="x")
        self.tb_top = top
        r1 = ttk.Frame(top); r1.pack(fill="x")
        r2 = ttk.Frame(top); r2.pack(fill="x")
        r3 = ttk.Frame(top); r3.pack(fill="x")

        # 行1：代码输入(触屏弹虚拟键盘) / 分析 / 周期 / 副图指标
        ttk.Label(r1, text="代码:").pack(side="left")
        self.code_var = tk.StringVar()
        ent = ttk.Entry(r1, textvariable=self.code_var, width=9)
        ent.pack(side="left", padx=2)
        ent.bind("<Return>", lambda e: self.run())
        self.btn_run = ttk.Button(r1, text="分析预测", command=self.run)
        self.btn_run.pack(side="left", padx=2)
        ttk.Button(r1, text="全屏", command=self.chart_fullscreen).pack(
            side="left", padx=2)
        ttk.Label(r1, text="K线:").pack(side="left")
        cb = ttk.Combobox(r1, textvariable=self.show_n, width=4, state="readonly",
                          values=[30, 60, 90, 120])
        cb.pack(side="left", padx=2)
        cb.bind("<<ComboboxSelected>>", lambda e: self._rerender())
        ttk.Label(r1, text="副图:").pack(side="left")
        ci = ttk.Combobox(r1, textvariable=self.ind_name, width=5, state="readonly",
                          values=["MACD", "KDJ", "RSI"])
        ci.pack(side="left", padx=2)
        ci.bind("<<ComboboxSelected>>", lambda e: self._rerender())

        # 行2：均线开关 + 报告类操作
        for nn in sorted(MA_COLORS):
            tk.Checkbutton(r2, text=f"MA{nn}", variable=self.ma_on[nn],
                           command=self._rerender, font=("Consolas", 9),
                           bg=DARK_BG, fg=FG_MAIN, activebackground=DARK_BG,
                           activeforeground=FG_MAIN,
                           selectcolor=FIELD_BG).pack(side="left")
        ttk.Button(r2, text="复制报告", command=self.copy_report).pack(side="left", padx=2)
        ttk.Button(r2, text="导出报告", command=self.export_report).pack(side="left", padx=2)
        ttk.Button(r2, text="样本明细", command=self.show_samples).pack(side="left", padx=2)
        self.btn_ai = ttk.Button(r2, text="AI分析", command=self.ai_analyze)
        self.btn_ai.pack(side="left", padx=2)

        # 行3：系统操作（触屏常用）
        if CACHE_OK:
            ttk.Button(r3, text="更新缓存",
                       command=self.refresh_cache).pack(side="left", padx=2)
        ttk.Button(r3, text="WiFi", command=self._wifi_dialog).pack(side="left", padx=2)
        ttk.Button(r3, text="设置", command=self.open_settings).pack(side="left", padx=2)
        ttk.Button(r3, text="重启", command=self._power_reboot).pack(side="left", padx=2)
        ttk.Button(r3, text="关机", command=self._power_off).pack(side="left", padx=2)

        self.info_var = tk.StringVar(value="")
        ttk.Label(r3, textvariable=self.info_var, foreground=TITLE_TXT,
                  font=("Microsoft YaHei", 9), wraplength=260,
                  justify="left").pack(side="left", padx=6)
        self.hover_var = tk.StringVar(value="")
        hk = ttk.Label(r3, textvariable=self.hover_var, foreground="#4da3ff",
                       font=("Consolas", 9))
        hk.pack(side="right")

    def _build_body(self):
        body = tk.Frame(self.root)
        body.pack(fill="both", expand=True)

        # ---- 左侧：自选池（触屏可折叠，默认收起省空间） ----
        self._watch_open = True
        self.btn_wfold = ttk.Button(body, text="自选\n股\n◂", width=4,
                                    command=self._toggle_watch)
        wf = ttk.LabelFrame(body, text=" 自选池 ", padding=4)
        self.wf = wf
        wf.pack(side="left", fill="y", padx=(8, 2), pady=2)
        self.watch_list = tk.Listbox(wf, width=15, font=("Consolas", 10),
                                     exportselection=False, bg=PANEL_BG,
                                     fg=FG_MAIN, selectbackground="#2b3540",
                                     selectforeground="#ffffff",
                                     relief="flat", highlightthickness=0)
        self.watch_list.pack(fill="both", expand=True)
        self.watch_list.bind("<Double-Button-1>", self._on_pick)
        bf = ttk.Frame(wf)
        bf.pack(fill="x", pady=(4, 0))
        ttk.Button(bf, text="+ 加自选", width=8,
                   command=self.add_watch).pack(side="left", padx=1)
        ttk.Button(bf, text="- 删除", width=7,
                   command=self.del_watch).pack(side="left", padx=1)

        # ---- 中部：图表 + 指数条 ----
        left = tk.Frame(body)
        left.pack(side="left", fill="both", expand=True)
        self._body_left = left          # 折叠自选池时的pack锚点
        self._watch_open = False        # 触屏默认折叠
        self._apply_watch_collapse()
        self.cv_main = Chart(left, self.PANEL_H["main"])
        self.cv_vol = Chart(left, self.PANEL_H["vol"])
        self.cv_ind = Chart(left, self.PANEL_H["ind"])
        for cv in (self.cv_main, self.cv_vol, self.cv_ind):
            cv.pack(fill="x", padx=(2, 2))
        idxbar = ttk.LabelFrame(left, text=" 五大指数 ", padding=(6, 3))
        idxbar.pack(fill="x", padx=(2, 2), pady=(4, 0))
        self.idx_bar = idxbar
        self.idx_labels = {}
        for col, (code, name) in enumerate(INDEX_CODES):
            idxbar.columnconfigure(col, weight=1, uniform="idx")
            cell = tk.Frame(idxbar, bg=DARK_BG)
            cell.grid(row=0, column=col, sticky="nsew", padx=4)
            tk.Label(cell, text=name, font=("Microsoft YaHei", 9),
                     fg=AXIS_TXT, bg=DARK_BG).grid(row=0, column=0,
                                                   sticky="w")
            lc = tk.Label(cell, text="-", font=("Consolas", 10, "bold"),
                          bg=DARK_BG)
            lc.grid(row=0, column=1, sticky="e", padx=(6, 0))
            lp = tk.Label(cell, text="-", font=("Consolas", 11, "bold"),
                          fg=FG_MAIN, bg=DARK_BG)
            lp.grid(row=1, column=0, columnspan=2, sticky="w")
            self.idx_labels[code] = (lp, lc)
        idxbar.columnconfigure(len(INDEX_CODES), weight=0)

        right = ttk.LabelFrame(body, text=" 预测参考 ", padding=4)
        right.pack(side="right", fill="y", padx=(2, 8), pady=6)
        self.frm_right = right
        self.side_txt = tk.Text(right, width=44, font=("Microsoft YaHei", 9),
                                relief="flat", bg=PANEL_BG, fg=FG_MAIN,
                                insertbackground=FG_MAIN,
                                selectbackground="#2b3540")
        self.side_txt.pack(fill="both", expand=True)

        bottom = tk.Frame(self.root, bg=DARK_BG)
        bottom.pack(fill="both", padx=8, pady=(2, 6))
        self.frm_bottom = bottom
        self.txt = tk.Text(bottom, height=8, font=("Consolas", 9),
                           bg="#12171d", fg="#cfd8e0",
                           insertbackground=FG_MAIN, relief="flat",
                           selectbackground="#2b3540")
        self.txt.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(bottom, command=self.txt.yview)
        sb.pack(side="right", fill="y")
        self.txt.config(yscrollcommand=sb.set)

        # 十字光标事件（元素在各面板内部，仅坐标移动，无整图重绘）
        self.chart_keys = [("main", self.cv_main), ("vol", self.cv_vol),
                           ("ind", self.cv_ind)]
        for key, cv in self.chart_keys:
            cv.bind("<Motion>", lambda e, k=key: self._on_motion(e, k))
            cv.bind("<Leave>", lambda e, k=key: self._on_leave(e, k))
            cv.bind("<Configure>", self._on_resize)
            cv.bind("<MouseWheel>", self._on_wheel)
            cv.bind("<Button-4>", self._on_wheel)
            cv.bind("<Button-5>", self._on_wheel)
    # ---------- 运行分析 ----------

    def _progress(self, msg):
        """后台线程进度 -> 主线程状态栏。"""
        try:
            self.root.after(0, lambda: self.info_var.set(msg))
        except RuntimeError:
            pass

    def _warm_cache(self):
        """启动后台预热全市场代码表（过期才真正联网刷新）。"""
        try:
            ensure_codes(self._progress)
        except Exception:
            pass

    def refresh_cache(self):
        self.info_var.set("正在更新缓存数据库（全市场代码表）...")
        self._run_bg(lambda: refresh_all_codes(self._progress),
                     self._cache_done)

    def _cache_done(self, res, err):
        if err:
            self.info_var.set(f"缓存更新失败: {err}")
            messagebox.showerror("更新缓存", str(err))
            return
        self.info_var.set("缓存已就绪：日K/代码表/分层池 本地命中，不再重复爬取")

    def _run_bg(self, fn, done, tries_max=4800, on_timeout=None):
        """后台线程执行 fn，完成后主线程调用 done(result|None, err|None)。
        tries_max: 250ms/次 的检查上限；on_timeout: 超时后的降级回调。"""
        holder = {}

        def worker():
            try:
                holder["r"] = fn()
            except Exception as e:
                holder["e"] = e

        threading.Thread(target=worker, daemon=True).start()

        def check(tries=0):
            if "r" in holder:
                done(holder["r"], None)
            elif "e" in holder:
                done(None, holder["e"])
            elif tries < tries_max:
                self.root.after(250, lambda: check(tries + 1))
            elif on_timeout is not None:
                on_timeout()
            else:
                done(None, RuntimeError("后台任务超时"))
        self.root.after(200, check)

    def run(self, sector_only=False):
        try:
            full = normalize_code(self.code_var.get())
        except ValueError as e:
            messagebox.showwarning("代码有误", str(e))
            return
        self.btn_run.config(state="disabled")
        if sector_only:
            self.info_var.set("同板块模式：仅拉取同行业个股...")
            self._run_bg(lambda: analyze(full, self._progress, sector_only=True),
                         self._done_load)
        else:
            self.info_var.set("正在拉取数据并计算（3分钟内完不成自动转同板块）...")
            self._run_bg(lambda: analyze(full, self._progress),
                         self._done_load,
                         tries_max=720,            # 180s / 0.25s
                         on_timeout=lambda: self.run(sector_only=True))

    def _done_load(self, res, err):
        if err:
            self._fail(str(err))
            return
        self._loaded(res)

    def _auto_refresh(self):
        """每15分钟静默重跑当前代码分析，刷新当日实时K线与预测。"""
        code = self.code_var.get()
        if code:
            try:
                full = normalize_code(code)
                self._run_bg(lambda: analyze(full), self._refresh_done)
            except ValueError:
                pass
        self.root.after(self.REFRESH_MS, self._auto_refresh)

    def _refresh_done(self, res, err):
        if err or not res:
            return                      # 静默失败，下个周期再试
        ai = self.ai_text
        self._loaded(res)
        self.ai_text = ai               # 自动刷新不清空AI分析结果
        if ai:
            self._write_side()
        q = res["quote"]
        self.info_var.set(
            f"[自动刷新 {time.strftime('%H:%M')}] " + self.info_var.get())

    def _tick_done(self, q, err):
        self._tick_busy = False
        res = self.res
        if err or not q or not res:
            return
        old_snap = (res["quote"].get("time") or "")[:8]
        new_snap = (q.get("time") or "")[:8]
        res["quote"] = q
        if new_snap != old_snap and old_snap:
            # 跨快照日（如开盘后出现今日bar/新交易日）→ 触发完整重分析
            try:
                full = normalize_code(self.code_var.get())
                self._run_bg(lambda: analyze(full), self._refresh_done)
            except ValueError:
                pass
            return
        if res.get("has_live"):
            live = res["disp_rows"][-1]
            live["close"] = q["price"]
            live["high"] = max(live["high"], q["price"])
            live["low"] = min(live["low"], q["price"]) if q["low"] > 0 else live["low"]
            tp = res["t_pred"]
            for pp in (10, 25, 50, 75, 90):     # 预测区间并入最新高低
                tp["hi"][pp] = round(max(tp["hi"][pp], live["high"]), 2)
                tp["lo"][pp] = round(min(tp["lo"][pp], live["low"]), 2)
            res["live_high"] = live["high"]
            res["live_low"] = live["low"]
            tb = res.get("tpred_bar")
            if tb:                               # T日预测叠加层同步外扩
                tb["high"] = max(tb["high"], live["high"])
                tb["low"] = min(tb["low"], live["low"])
        res["phase"] = market_phase_text(q.get("time"))
        self._set_info(q)
        self._rerender()

    def _tick(self):
        """秒级实时：只拉一次行情快照，更新现价/实时bar/预测区间/状态角标。"""
        self.root.after(self.TICK_MS, self._tick)
        if not self.res or getattr(self, "_tick_busy", False):
            return
        code = self.code_var.get()
        if not code:
            return
        try:
            full = normalize_code(code)
        except ValueError:
            return
        self._tick_busy = True
        self._run_bg(lambda: fetch_quote(full), self._tick_done)

    def _fail(self, msg):
        self.btn_run.config(state="normal")
        self.info_var.set("失败")
        messagebox.showerror("错误", msg)

    def _loaded(self, res):
        self.btn_run.config(state="normal")
        self.res = res
        self.ai_text = ""
        self._save_ini()
        self._set_info()
        self._rerender()

    def _set_info(self, q=None):
        """顶栏信息行（盘前不显示过期今开，锚定提示在图表右下角）。"""
        res = self.res
        q = q or res["quote"]
        chg = (q["price"] / res["prev_close"] - 1) * 100
        if res.get("pre_open"):
            self.info_var.set(
                f"{q['name']} ({res['full_code']})  "
                f"昨收{res['prev_close']:.2f}  "
                f"现价{q['price']:.2f}({chg:+.2f}%)  快照{q['time']}")
        else:
            self.info_var.set(
                f"{q['name']} ({res['full_code']})  昨收{res['prev_close']:.2f} "
                f"今开{q['open']:.2f}(缺口{res['gap_today']:+.2f}%) "
                f"现价{q['price']:.2f}({chg:+.2f}%)  快照{q['time']}"
                + ("  [含盘中实时bar]" if res["has_live"] else ""))

    def _rerender(self):
        if not self.res:
            return
        try:
            n = int(self.show_n.get())
        except Exception:
            n = 60
        n = max(20, min(n, 250))
        self.view = slice_view(self.res, n)
        self._draw_main()
        self._draw_vol()
        name = self.ind_name.get()
        if name == "MACD":
            self._draw_macd()
        elif name == "KDJ":
            self._draw_kdj()
        else:
            self._draw_rsi()
        self._write_side()
        self._write_report()

    def _on_wheel(self, event):
        """滚轮缩放K线：上滚放大（减少根数），下滚缩小。"""
        if not self.res:
            return
        if getattr(event, "num", None) == 4:
            step = -10
        elif getattr(event, "num", None) == 5:
            step = 10
        else:
            step = -10 if event.delta > 0 else 10
        try:
            n = int(self.show_n.get()) + step
        except Exception:
            n = 60
        n = max(20, min(250, n))
        self.show_n.set(n)
        self.info_var.set(f"K线根数: {n}")
        # 防抖：连续滚动只触发一次重绘
        if getattr(self, "_wheel_job", None):
            self.root.after_cancel(self._wheel_job)
        self._wheel_job = self.root.after(60, self._rerender)

    def _on_resize(self, _event):
        if getattr(self, "_resize_job", None):
            self.root.after_cancel(self._resize_job)
        self._resize_job = self.root.after(200, self._rerender)

    # ---------- 绘图工具 ----------

    def _geom(self, cv, n_bars):
        w = max(cv.winfo_width(), 900)
        h = int(cv["height"])
        L, R, T, B = 58, 70, 16, 20
        pw, ph = w - L - R, h - T - B
        bw = pw / n_bars
        return {"w": w, "h": h, "L": L, "R": R, "T": T, "B": B,
                "pw": pw, "ph": ph, "bw": bw, "n": n_bars}

    @staticmethod
    def _pad_range(lo, hi, ratio=0.06):
        rng = (hi - lo) or 1.0
        pad = rng * ratio
        return lo - pad, hi + pad

    def _axes(self, cv, g, lo, hi, fmt="{:.2f}", ngrid=4):
        def ymap(v):
            return g["T"] + (hi - v) / (hi - lo) * g["ph"]
        for k in range(ngrid + 1):
            v = lo + (hi - lo) * k / ngrid
            y = ymap(v)
            cv.create_line(g["L"], y, g["w"] - g["R"], y, fill=GRID_C)
            txt = fmt(v) if callable(fmt) else fmt.format(v)
            cv.create_text(g["L"] - 4, y, text=txt, anchor="e",
                           font=("Consolas", 8), fill=AXIS_TXT)
        return ymap

    def _line(self, cv, xs_fn, vals, ymap, color, width=1):
        """整条折线一次绘制（None 断开），item 数从 N 段降为少数几条。"""
        pts = []
        segs = []
        for i, v in enumerate(vals):
            if v is None:
                if len(pts) >= 2:
                    segs.append(list(pts))
                pts = []
                continue
            x, yy = xs_fn(i), ymap(v)
            pts.extend((x, yy))
        if len(pts) >= 2:
            segs.append(list(pts))
        for s in segs:
            cv.create_line(*s, fill=color, width=width,
                           joinstyle="round", capstyle="round")

    def _finish_panel(self, cv, g, key, lo, hi, dates, fmt=None):
        """登记缩放信息并创建光标元素（层级创建时一次固定）。"""
        g["lo_v"], g["hi_v"] = lo, hi
        g["dates"] = dates
        g["fmt"] = fmt or (lambda v: f"{v:.2f}")
        g["key"] = key
        self.scales[key] = g
        g["vid"] = cv.create_line(0, 0, 0, 0, state="hidden", fill=CROSS_C,
                                  dash=(4, 3))
        g["hid"] = cv.create_line(0, 0, 0, 0, state="hidden", fill=CROSS_C,
                                  dash=(4, 3))
        g["pid"] = cv.create_text(0, 0, text="", state="hidden",
                                  fill="#ffffff",
                                  font=("Consolas", 9, "bold"))
        g["pbg"] = cv.create_rectangle(0, 0, 0, 0, state="hidden",
                                       fill="#1971c2", outline="")
        g["did"] = cv.create_text(0, 0, text="", state="hidden",
                                  fill="#ffffff",
                                  font=("Consolas", 9, "bold"))
        g["dbgd"] = cv.create_rectangle(0, 0, 0, 0, state="hidden",
                                        fill="#333c46", outline="")
        cv.tag_lower(g["dbgd"], g["did"])
        cv.tag_raise(g["pid"])
        g["_shown"] = False

    def _draw_main(self):
        cv, v = self.cv_main, self.view
        cv.delete("all")
        bars = v["bars"]
        g = self._geom(cv, len(bars))
        los = [b["low"] for b in bars]
        his = [b["high"] for b in bars]
        for nn, on in self.ma_on.items():
            if on.get():
                vals = [x for x in v["ma"][nn] if x is not None]
                if vals:
                    los.append(min(vals))
                    his.append(max(vals))
        if v.get("tpred"):
            los.append(v["tpred"]["low"])
            his.append(v["tpred"]["high"])
        lo, hi = self._pad_range(min(los), max(his))

        def ymap(val):
            return g["T"] + (hi - val) / (hi - lo) * g["ph"]

        def xs(i):
            return g["L"] + g["bw"] * (i + 0.5)
        self._axes(cv, g, lo, hi)

        for nn in sorted(MA_COLORS):
            if self.ma_on[nn].get():
                self._line(cv, xs, v["ma"][nn], ymap, MA_COLORS[nn])

        yo = yc = None
        for i, b in enumerate(bars):
            x = xs(i)
            isp = b["date"] in ("T+1预测", "T日预测")
            up = b["close"] >= b["open"]
            color = PRED_C if isp else (UP if up else DOWN)
            dash = (3, 2) if isp else ()
            yo, yc = ymap(b["open"]), ymap(b["close"])
            cv.create_line(x, ymap(b["high"]), x, ymap(b["low"]),
                           fill=color, dash=dash)
            bw2 = max(g["bw"] * 0.62, 2)
            ty, by2 = min(yo, yc), max(yo, yc)
            if by2 - ty < 1:
                by2 = ty + 1
            cv.create_rectangle(x - bw2 / 2, ty, x + bw2 / 2, by2,
                                fill="" if isp else color,
                                outline=color, dash=dash)

        # 当日预测：白色虚线幽灵K线叠加在实时bar同一位置
        tpred = v.get("tpred")
        if tpred:
            li = len(v["bars"]) - 2      # 实时bar在视图中的下标
            x = xs(li)
            cv.create_line(x, ymap(tpred["high"]), x, ymap(tpred["low"]),
                           fill=TPRED_C, dash=(3, 2))
            y1 = ymap(max(tpred["open"], tpred["close"]))
            y2 = ymap(min(tpred["open"], tpred["close"]))
            bw3 = max(g["bw"] * 0.62, 2) + 3   # 略宽于实体，形成外框
            cv.create_rectangle(x - bw3 / 2, y1, x + bw3 / 2,
                                max(y2, y1 + 1),
                                fill="", outline=TPRED_C, dash=(3, 2))

        for i, day, typ, txt in v["signals"]:
            if i >= len(bars) - 1:
                continue
            x = xs(i)
            if typ == "BUY":
                y = ymap(bars[i]["low"]) + 5
                cv.create_polygon(x, y, x - 5, y + 9, x + 5, y + 9,
                                  fill=UP, outline="")
                cv.create_text(x, y + 15, text="B", fill=UP,
                               font=("Arial", 8, "bold"))
            else:
                y = ymap(bars[i]["high"]) - 5
                cv.create_polygon(x, y, x - 5, y - 9, x + 5, y - 9,
                                  fill=DOWN, outline="")
                cv.create_text(x, y - 15, text="S", fill=DOWN,
                               font=("Arial", 8, "bold"))

        pb = bars[-1]
        if len(bars) >= 2 and bars[-2]["date"] == "T日预测":
            tb = bars[-2]
            cv.create_text(xs(len(bars) - 1) - 44, g["T"] - 3,
                           text=f"T日C:{tb['close']:.2f}", fill=TPRED_C,
                           anchor="e",
                           font=("Microsoft YaHei", 8, "bold"))
        cv.create_text(xs(len(bars) - 1), g["T"] - 3,
                       text=f"{v.get('pred_label', 'T+1')} C:{pb['close']:.2f}",
                       fill=PRED_C,
                       font=("Microsoft YaHei", 8, "bold"))
        lx = g["L"] + 2
        for nn in sorted(MA_COLORS):
            if self.ma_on[nn].get():
                cv.create_text(lx, 6, text=f"MA{nn}",
                               fill=MA_COLORS[nn],
                               font=("Consolas", 8, "bold"), anchor="w")
                lx += 36
        step = max(1, len(bars) // 10)
        for i in range(0, len(bars), step):
            cv.create_text(xs(i), g["h"] - 7, text=v["dates"][i][5:],
                           font=("Consolas", 7), fill=AXIS_TXT)
        self._finish_panel(cv, g, "main", lo, hi, v["dates"])

    # ---------- 成交量 ----------

    def _draw_vol(self):
        cv, v = self.cv_vol, self.view
        cv.delete("all")
        vols = list(v["vols"])
        while vols and vols[-1] is None:   # 剔除尾部预测占位空槽
            vols.pop()
        n = len(v["bars"])
        g = self._geom(cv, n)
        vmax = max(vols) if vols else 1.0
        lo, hi = 0, vmax * 1.08

        def ymap(val):
            return g["T"] + (hi - val) / (hi - lo) * g["ph"]

        def xs(i):
            return g["L"] + g["bw"] * (i + 0.5)
        self._axes(cv, g, lo, hi, lambda x: f"{x/10000:.0f}万", 2)
        bw2 = max(g["bw"] * 0.62, 1)
        for i, vol in enumerate(vols):
            c = UP if v["bars"][i]["close"] >= v["bars"][i]["open"] else DOWN
            cv.create_rectangle(xs(i) - bw2 / 2, ymap(vol),
                                xs(i) + bw2 / 2, ymap(0),
                                fill=c, outline=c)
        if len(vols) >= 5:
            mv = sum(vols[-5:]) / 5
            cv.create_line(g["L"], ymap(mv), g["w"] - g["R"], ymap(mv),
                           fill="#e8890c", dash=(5, 3))
            cv.create_text(g["w"] - g["R"] - 4, ymap(mv) - 7,
                           text=f"5日均量 {mv/10000:.0f}万手",
                           anchor="e", font=("Consolas", 8), fill="#e8890c")
        cv.create_text(g["L"] + 2, g["T"] - 3, text="VOLUME(手)", anchor="w",
                       font=("Microsoft YaHei", 8), fill=TITLE_TXT)
        step = max(1, n // 10)
        for i in range(0, n, step):
            cv.create_text(xs(i), g["h"] - 7, text=v["dates"][i][5:],
                           font=("Consolas", 7), fill=AXIS_TXT)
        self._finish_panel(cv, g, "vol", lo, hi, v["dates"],
                           fmt=lambda v: fmt_vol_cn(v) + "手")

    # ---------- 可选指标 ----------

    def _draw_macd(self):
        cv, v = self.cv_ind, self.view
        cv.delete("all")
        dif, dea, mh = v["dif"], v["dea"], v["mhist"]
        n = len(v["bars"])
        g = self._geom(cv, n)
        vals = [x for x in dif + dea + mh if x is not None]
        lo, hi = self._pad_range(min(vals + [0]), max(vals + [0]), 0.12)

        def ymap(val):
            return g["T"] + (hi - val) / (hi - lo) * g["ph"]

        def xs(i):
            return g["L"] + g["bw"] * (i + 0.5)
        zero = ymap(0)
        cv.create_line(g["L"], zero, g["w"] - g["R"], zero, fill=GRID_C)
        self._axes(cv, g, lo, hi, "{:.2f}", 2)
        mbw2 = max(g["bw"] * 0.3, 1.5)
        for i, hv in enumerate(mh):
            if hv is None:
                continue
            c = UP if hv >= 0 else DOWN
            y = ymap(hv)
            cv.create_rectangle(xs(i) - mbw2, min(y, zero),
                                xs(i) + mbw2, max(y, zero),
                                fill=c, outline=c)
        self._line(cv, xs, dif, ymap, "#e8890c")
        self._line(cv, xs, dea, ymap, "#1971c2")
        lv = lambda arr: [x for x in arr if x is not None]
        ld, la, lh = (lv(dif), lv(dea), lv(mh))
        info = f"DIF:{ld[-1]:.3f}  DEA:{la[-1]:.3f}  MACD:{lh[-1]:.3f}" \
            if ld and la and lh else ""
        cv.create_text(g["L"] + 2, g["T"] - 3,
                       text=f"MACD  橙DIF / 蓝DEA / 红绿柱    {info}",
                       anchor="w", font=("Microsoft YaHei", 8), fill=TITLE_TXT)
        self._finish_panel(cv, g, "ind", lo, hi, v["dates"],
                           fmt=lambda v: f"{v:.3f}")

    def _draw_kdj(self):
        cv, v = self.cv_ind, self.view
        cv.delete("all")
        k, d, j = v["k"], v["d"], v["j"]
        n = len(v["bars"])
        g = self._geom(cv, n)
        lo, hi = self._pad_range(min(j + [0]), max(j + [100]), 0.06)

        def ymap(val):
            return g["T"] + (hi - val) / (hi - lo) * g["ph"]

        def xs(i):
            return g["L"] + g["bw"] * (i + 0.5)
        for gv in (20, 50, 80):
            y = ymap(gv)
            cv.create_line(g["L"], y, g["w"] - g["R"], y,
                           fill=GUIDE_C if gv != 50 else GRID_C)
            cv.create_text(g["L"] - 4, y, text=str(gv), anchor="e",
                           font=("Consolas", 8), fill=AXIS_TXT)
        self._line(cv, xs, k, ymap, "#e8890c")
        self._line(cv, xs, d, ymap, "#1971c2")
        self._line(cv, xs, j, ymap, "#9c36b5")
        cv.create_text(g["L"] + 2, g["T"] - 3,
                       text=(f"KDJ  橙K / 蓝D / 紫J    "
                             f"K:{k[-1]:.1f}  D:{d[-1]:.1f}  J:{j[-1]:.1f}"),
                       anchor="w", font=("Microsoft YaHei", 8), fill=TITLE_TXT)
        self._finish_panel(cv, g, "ind", lo, hi, v["dates"],
                           fmt=lambda v: f"{v:.1f}")

    def _draw_rsi(self):
        cv, v = self.cv_ind, self.view
        cv.delete("all")
        n = len(v["bars"])
        g = self._geom(cv, n)
        lo, hi = self._pad_range(0, 100, 0.02)

        def ymap(val):
            return g["T"] + (hi - val) / (hi - lo) * g["ph"]

        def xs(i):
            return g["L"] + g["bw"] * (i + 0.5)
        for gv in (30, 50, 70):
            y = ymap(gv)
            cv.create_line(g["L"], y, g["w"] - g["R"], y,
                           fill=GUIDE_C if gv != 50 else GRID_C)
            cv.create_text(g["L"] - 4, y, text=str(gv), anchor="e",
                           font=("Consolas", 8), fill=AXIS_TXT)
        self._line(cv, xs, v["rsi6"], ymap, "#e8890c")
        self._line(cv, xs, v["rsi12"], ymap, "#1971c2")
        last6 = [x for x in v["rsi6"] if x is not None]
        last12 = [x for x in v["rsi12"] if x is not None]
        label = f"RSI  橙RSI6:{last6[-1]:.1f} / 蓝RSI12:{last12[-1]:.1f}" \
            if last6 and last12 else "RSI"
        cv.create_text(g["L"] + 2, g["T"] - 3, text=label, anchor="w",
                       font=("Microsoft YaHei", 8), fill=TITLE_TXT)
        self._finish_panel(cv, g, "ind", lo, hi, v["dates"],
                           fmt=lambda v: f"{v:.1f}")

    # ---------- 十字光标 ----------

    def _on_motion(self, event, key):
        """十字光标：线/标签连续跟随鼠标，数据读数吸附最近K线。"""
        if key not in self.scales or not self.view:
            return
        sg = self.scales[key]
        cv = {"main": self.cv_main, "vol": self.cv_vol,
              "ind": self.cv_ind}[key]

        # 轻操作：竖线/横线/价格标签逐像素跟随（仅悬停面板，缩小重绘区）
        xv = max(min(event.x, sg["w"] - sg["R"]), sg["L"])
        y = max(min(event.y, sg["T"] + sg["ph"]), sg["T"])
        cv.coords(sg["vid"], xv, sg["T"] + 2, xv, sg["h"] - sg["B"])
        cv.coords(sg["hid"], sg["L"], y, sg["w"] - sg["R"], y)
        price = sg["hi_v"] - (y - sg["T"]) / sg["ph"] * (
            sg["hi_v"] - sg["lo_v"])
        fmt = sg.get("fmt")
        txt = fmt(price) if fmt else f"{price:.2f}"
        px = sg["w"] - sg["R"] + 30
        cv.coords(sg["pid"], px, y)
        cv.itemconfigure(sg["pid"], text=txt)
        cv.coords(sg["pbg"], px - 27, y - 9, px + 29, y + 9)

        first = not sg["_shown"]
        if first:
            for it in ("vid", "hid", "pid", "pbg", "did", "dbgd"):
                cv.itemconfigure(sg[it], state="normal")
            cv.tag_raise(sg["pbg"])
            cv.tag_raise(sg["pid"])
            sg["_shown"] = True

        # 吸附数据：仅跨越K线时更新（重操作）
        idx = int((event.x - sg["L"]) / sg["bw"])
        idx = max(0, min(sg["n"] - 1, idx))
        sig = (key, idx)
        if getattr(self, "_mtn", None) == sig and not first:
            return
        self._mtn = sig
        cx = sg["L"] + sg["bw"] * (idx + 0.5)
        date = sg["dates"][idx]
        dl = date[:10]

        c2 = cv
        c2.coords(sg["did"], cx, sg["h"] - sg["B"] // 2 + 2)
        c2.itemconfigure(sg["did"], text=dl)
        w_bg = len(dl) * 7 + 10
        c2.coords(sg["dbgd"], cx - w_bg / 2,
                  sg["h"] - sg["B"] // 2 - 5,
                  cx + w_bg / 2, sg["h"] - sg["B"] // 2 + 11)

        bars = self.view["bars"]
        if idx >= len(bars):
            return
        b = bars[idx]
        v = self.view
        ind_txt = ""
        name = self.ind_name.get()
        if b["date"] != "T+1预测" and idx < len(v["dif"]) \
                and v["dif"][idx] is not None:
            if name == "MACD":
                if v["dea"][idx] is not None and v["mhist"][idx] is not None:
                    ind_txt = (f"  DIF:{v['dif'][idx]:.3f} "
                               f"DEA:{v['dea'][idx]:.3f} "
                               f"MACD:{v['mhist'][idx]:.3f}")
            elif name == "KDJ":
                ind_txt = (f"  K:{v['k'][idx]:.1f} D:{v['d'][idx]:.1f} "
                           f"J:{v['j'][idx]:.1f}")
            else:
                r6 = v["rsi6"][idx]
                r12 = v["rsi12"][idx]
                ind_txt = ("  RSI6:%.1f RSI12:%s"
                           % (r6, f"{r12:.1f}" if r12 is not None else "-"))
        if b["date"] in ("T+1预测", "T日预测"):
            tag = "预测T+1" if b["date"] == "T+1预测" else "预测T日"
            self.hover_var.set(
                f"[{tag}] 开{b['open']:.2f} 高{b['high']:.2f} "
                f"低{b['low']:.2f} 收{b['close']:.2f}")
            return
        sig_txt = ""
        for s_i, _day, s_t, s_txt in self.view["signals"]:
            if s_i == idx:
                sig_txt = f"  ◆[{'买' if s_t == 'BUY' else '卖'}] {s_txt}"
        pc = bars[idx - 1]["close"] if idx > 0 else (
            self.res["disp_rows"][self.view["off"] - 1]["close"]
            if self.view["off"] > 0 else self.res["prev_close"])
        chg = (b["close"] / pc - 1) * 100
        vol_s = (fmt_vol_cn(b["vol"]) + "手") if b.get("vol") else "-"
        self.hover_var.set(
            f"{b['date']} 开{b['open']:.2f} 高{b['high']:.2f} "
            f"低{b['low']:.2f} 收{b['close']:.2f} ({chg:+.2f}%) "
            f"量{vol_s}{ind_txt}{sig_txt}")

    def _on_leave(self, _event, _key=None):
        self.hover_var.set("")
        self._mtn = None
        for k2 in ("main", "vol", "ind"):
            sg2 = self.scales.get(k2)
            if not sg2:
                continue
            c2 = {"main": self.cv_main, "vol": self.cv_vol,
                  "ind": self.cv_ind}[k2]
            for it in ("vid", "hid", "pid", "pbg", "did", "dbgd"):
                c2.itemconfigure(sg2[it], state="hidden")
            sg2["_shown"] = False

    def _report_text(self):
        res, tp, pred, q = self.res, self.res["t_pred"], self.res["pred"], self.res["quote"]
        L = []
        L.append("=" * 64)
        L.append(f"{q['name']} ({res['full_code']})  快照 {q['time']}  "
                 f"昨收 {res['prev_close']:.2f}")
        L.append(f"今开 {q['open']:.2f} (缺口 {res['gap_today']:+.2f}%)  "
                 f"现价 {q['price']:.2f}")
        idx_txt = (f"{res['idx_chg_today']:+.2f}%"
                   if res["idx_chg_today"] is not None else "未知")
        vr_txt = (f"量比 {res['vr_now']:.2f}（{res['cur_regime']}）"
                  if res["vr_now"] is not None else "数据不足")
        sec_txt = (f"{res['sector_name']} {res['sector_chg_today']:+.2f}%"
                   if res["sector_name"] and res["sector_chg_today"] is not None
                   else "未知")
        L.append(f"大盘(上证) {idx_txt} | 板块 {sec_txt} | 本股量能 {vr_txt}")
        L.append(f"-- 今日(T)预测 -- 锚定{res.get('anchor', '今开')}")
        for p in (10, 25, 50, 75, 90):
            L.append(f"P{p}: 收盘{tp['cl'][p]:.2f} 最高{tp['hi'][p]:.2f} "
                     f"最低{tp['lo'][p]:.2f}")
        L.append(f"开盘->收盘 上行概率 {tp['up_prob']*100:.0f}%   "
                 f"有效样本 {res['src_n']}/{len(res['samples'])}"
                 f"（{res['filter_note']}）")
        lv = res.get("levels") or []
        if len(lv) > 1:
            L.append("分层上行概率: " + " | ".join(
                f"{x['label']} {x['up_prob']*100:.0f}%(n={x['n']})"
                for x in lv))
            w = {"L1": 0.6, "L2": 0.3, "L3": 0.1}
            L.append(f"融合权重: " +
                     " ".join(f"{x['label']}{w[x['key']]}" for x in lv))
        if res.get("pool_note"):
            L.append(res["pool_note"])
        if res["has_live"] and res["clamped"]:
            L.append(f"[盘中实时修正] 已实现最高 {res['live_high']:.2f} / "
                     f"最低 {res['live_low']:.2f}，已并入预测区间")
        L.append(f"-- {res.get('next_label', '次日(T+1)')}预测 --")
        L.append(f"开 {pred['open']:.2f} | 收 {pred['close']:.2f} | "
                 f"高 {pred['high']:.2f} | 低 {pred['low']:.2f}")
        sigs = res["signals"]
        L.append(f"-- 近期买卖信号({min(len(sigs),12)}条) --")
        for i, day, typ, txt in sigs[-12:]:
            tag = "买" if typ == "BUY" else "卖"
            L.append(f"  {day} [{tag}] {txt}")
        if not sigs:
            L.append("  近期无")
        L.append("[提示] 历史统计推断仅供参考，不构成投资建议。")
        return "\n".join(L)

    def _write_report(self):
        self.txt.delete("1.0", "end")
        self.txt.insert("end", self._report_text())

    def _write_side(self):
        res = self.res
        tp, pred = res["t_pred"], res["pred"]
        t = self.side_txt
        t.delete("1.0", "end")

        def p(s=""):
            t.insert("end", s + "\n")

        def tag(s, c):
            t.insert("end", s + "\n", ("c",))
            t.tag_config("c", foreground=c)

        p(f"■ 今日(T)收盘预测  [锚定{res.get('anchor', '今开')}]")
        for pp in (10, 50, 90):
            p(f"  P{pp}: 收{tp['cl'][pp]:.2f} 高{tp['hi'][pp]:.2f} 低{tp['lo'][pp]:.2f}")
        p(f"  上行概率 {tp['up_prob']*100:.0f}%  "
          f"样本{res['src_n']}/{len(res['samples'])}")
        idx_txt = (f"{res['idx_chg_today']:+.2f}%"
                   if res["idx_chg_today"] is not None else "未知")
        vr_txt = (f"{res['vr_now']:.2f}({res['cur_regime']})"
                  if res["vr_now"] is not None else "-")
        p(f"  大盘 {idx_txt} | 量能 {vr_txt}")
        if res["sector_name"]:
            sec_txt = (f"{res['sector_chg_today']:+.2f}%"
                       if res["sector_chg_today"] is not None else "-")
            p(f"  板块 {res['sector_name']} {sec_txt}")
        p(f"  筛选: {res['filter_note']}")
        lv = res.get("levels") or []
        if len(lv) > 1:
            p("  分层上行概率: " + " | ".join(
                f"{x['label']}{x['up_prob']*100:.0f}%(n={x['n']})"
                for x in lv))
        if res.get("pool_note"):
            p(f"  {res['pool_note']}")
        if res["has_live"] and res["clamped"]:
            p(f"  [实时修正] 盘中已实现 高{res['live_high']:.2f} "
              f"低{res['live_low']:.2f}")
        p()
        p(f"■ {res.get('next_label', '次日(T+1)')}预测")
        p(f"  开{pred['open']:.2f} 收{pred['close']:.2f}")
        p(f"  高{pred['high']:.2f} 低{pred['low']:.2f}")
        p()
        p("■ 相似历史参考日期")
        p(f"(近{W_WINDOW}日形态匹配 Top{TOPK})")
        p(f"{'T日':<11}{'T+1日':<11}{'次日涨跌':>8}")
        for s in res["samples"]:
            chg1 = s["cl_o"] * 100
            mark = "*" if abs(s["gap"] * 100 - res["gap_today"]) <= 1.0 else ""
            p(f"{s['t_date']:<11}{s['n1_date']:<11}{chg1:>+7.1f}% {mark}")
        p()
        p("* = 开盘缺口与今日接近")
        p("──────────────────────")
        p("■ 最近买卖信号")
        sigs = res["signals"][-6:]
        if not sigs:
            p("  近期无")
        for n_i, (s_i, day, typ, txt) in enumerate(reversed(sigs)):
            tg = f"sig{n_i}"
            t.insert("end", f"  {day} [{'买' if typ == 'BUY' else '卖'}] ",
                     ("c",))
            t.tag_config(tg,
                         foreground=UP if typ == "BUY" else DOWN)
            t.insert("end", txt + "\n", (tg,))
        p("提示：前复权价统计推断，")
        p("仅供参考，不构成投资建议")
        p("──────────────────────")
        p("■ 市场状态")
        tg_ph = "phase_tag"
        t.insert("end", f"  ● {res.get('phase', '时间未知')}"
                 + ("（未开盘·预测锚定昨收）" if res.get("pre_open") else "")
                 + "\n", (tg_ph,))
        t.tag_config(tg_ph, foreground="#4da3ff",
                     font=("Microsoft YaHei", 10, "bold"))
        if getattr(self, "ai_text", ""):
            p()
            p("══════════════════════")
            tag_cfg = self.side_txt.tag_config
            self.side_txt.insert("end", "■ DeepSeek AI 分析\n", ("h3",))
            self.side_txt.tag_config("h3", foreground="#4da3ff",
                                     font=("Microsoft YaHei", 10, "bold"))
            self.side_txt.insert("end", self.ai_text + "\n")

    # ---------- 自选池 ----------

    def _load_config(self):
        cp = configparser.ConfigParser()
        if os.path.exists(INI_PATH):
            try:
                cp.read(INI_PATH, encoding="utf-8")
                codes = [c.strip() for c in
                         cp.get("watchlist", "codes", fallback="").split(",")
                         if c.strip()]
                self.watchlist = codes
                self._last_code = cp.get("ui", "last", fallback="")
                self.settings["theme"] = cp.get("ui", "theme",
                                                fallback="dark")
                self.settings["updown"] = cp.get("ui", "updown",
                                                 fallback="red_up")
                self.api_key = cp.get("deepseek", "api_key", fallback="")
                self.proxy_url = cp.get("proxy", "url", fallback="")
            except Exception:
                pass

    def _save_ini(self):
        cp = configparser.ConfigParser()
        if not cp.has_section("watchlist"):
            cp.add_section("watchlist")
        cp.set("watchlist", "codes", ",".join(self.watchlist))
        if not cp.has_section("ui"):
            cp.add_section("ui")
        cp.set("ui", "last", self.code_var.get())
        cp.set("ui", "theme", self.settings["theme"])
        cp.set("ui", "updown", self.settings["updown"])
        if not cp.has_section("deepseek"):
            cp.add_section("deepseek")
        cp.set("deepseek", "api_key", self.api_key)
        if not cp.has_section("proxy"):
            cp.add_section("proxy")
        cp.set("proxy", "url", getattr(self, "proxy_url", ""))
        try:
            with open(INI_PATH, "w", encoding="utf-8") as f:
                cp.write(f)
        except OSError as e:
            print(f"[ini] 保存失败: {e}")

    def _render_watchlist(self):
        self.watch_list.delete(0, "end")
        for c in self.watchlist:
            name = getattr(self, "_names", {}).get(c, "")
            self.watch_list.insert("end", f"{c} {name}")

    def add_watch(self):
        raw = self.code_var.get()
        if not raw:
            messagebox.showinfo("提示", "先在上方输入代码再点【加自选】")
            return
        try:
            full = normalize_code(raw)
        except ValueError as e:
            messagebox.showwarning("代码有误", str(e))
            return
        if full in self.watchlist:
            self.info_var.set(f"{full} 已在自选池")
            return
        self.watchlist.append(full)
        self._save_ini()
        self._refresh_names()

    def del_watch(self):
        sel = self.watch_list.curselection()
        if not sel:
            messagebox.showinfo("提示", "请先在列表中选中一项")
            return
        real = self.watch_list.get(sel[0]).split()[0]
        if real in self.watchlist:
            self.watchlist.remove(real)
            self._save_ini()
            self._render_watchlist()

    def _on_pick(self, _event):
        sel = self.watch_list.curselection()
        if not sel:
            return
        code = self.watchlist[sel[0]].split()[0]
        self.code_var.set(code)
        self.run()

    def _refresh_names(self):
        """批量拉自选池名称后刷新列表。"""
        if not self.watchlist:
            self._render_watchlist()
            return

        def fn():
            names = {}
            raw = http_get(QT_URL + ",".join(self.watchlist))
            for seg in raw.split(";"):
                seg = seg.strip()
                if "=" not in seg or "~" not in seg:
                    continue
                var_name = seg.split("=")[0].strip()   # 如 v_sz002241
                code = var_name.replace("v_", "", 1).lower()
                f = seg.split("~")
                if len(f) > 1 and code:
                    names[code] = f[1]
            return names

        def done(names, err):
            if err is None:
                self._names = names
            self._render_watchlist()
        self._run_bg(fn, done)

    # ---------- 触屏：自选池折叠 ----------

    def _toggle_watch(self):
        self._watch_open = not self._watch_open
        self._apply_watch_collapse()

    def _apply_watch_collapse(self):
        if self._watch_open:
            self.btn_wfold.pack_forget()
            self.wf.pack(side="left", fill="y", padx=(8, 2), pady=2,
                         before=self._body_left)
            self.btn_wfold.config(text="自选\n股\n◂")
        else:
            self.wf.pack_forget()
            self.btn_wfold.pack(side="left", fill="y", padx=(8, 0), pady=2,
                                before=self._body_left)
            self.btn_wfold.config(text="自选\n股\n▸")

    # ---------- 触屏：K线全屏模式 ----------

    def chart_fullscreen(self):
        """K线主图占满全屏，只留一个返回键。"""
        self._fs_watch_was_open = self._watch_open
        for w in (self.tb_top, self.cv_vol, self.cv_ind, self.idx_bar,
                  self.frm_right, self.frm_bottom,
                  self.wf if self._watch_open else self.btn_wfold):
            try:
                w.pack_forget()
            except Exception:
                pass
        self.cv_main.pack(fill="both", expand=True, padx=2, pady=2)
        self.fs_back = tk.Button(self.root, text="返回 ◂",
                                 font=("Microsoft YaHei", 11),
                                 bg="#233042", fg="#cfe3ff",
                                 activebackground="#2e4a66", relief="flat",
                                 command=self.chart_exit_fullscreen)
        self.fs_back.place(relx=1.0, rely=0.0, x=-4, y=4, anchor="ne")

    def chart_exit_fullscreen(self):
        try:
            self.fs_back.destroy()
        except Exception:
            pass
        self.tb_top.pack(fill="x")
        if self._fs_watch_was_open:
            self.wf.pack(side="left", fill="y", padx=(8, 2), pady=2,
                         before=self._body_left)
        else:
            self.btn_wfold.pack(side="left", fill="y", padx=(8, 0), pady=2,
                                before=self._body_left)
        self.cv_main.pack(fill="x", padx=(2, 2))
        self.cv_vol.pack(fill="x", padx=(2, 2))
        self.cv_ind.pack(fill="x", padx=(2, 2))
        self.idx_bar.pack(fill="x", padx=(2, 2), pady=(4, 0))
        self.frm_right.pack(side="right", fill="y", padx=(2, 8), pady=6)
        self.frm_bottom.pack(fill="both", padx=8, pady=(2, 6))
        try:
            self.root.update_idletasks()
            self._on_resize(None)
        except Exception:
            pass

    # ---------- 触屏：WiFi 管理（nmcli） ----------

    def _nm(self, args, timeout=25):
        try:
            p = subprocess.run(["nmcli"] + args, capture_output=True,
                               text=True, timeout=timeout)
            return p.returncode, (p.stdout or "") + (p.stderr or "")
        except Exception as e:
            return 1, str(e)

    def _wifi_dialog(self):
        win = tk.Toplevel(self.root)
        win.title("WiFi")
        win.transient(self.root)
        win.grab_set()
        frm = tk.Frame(win, bg=DARK_BG, padx=8, pady=8)
        frm.pack(fill="both", expand=True)
        self._wifi_st = tk.Label(frm, text="扫描中...",
                                 font=("Microsoft YaHei", 11),
                                 bg=DARK_BG, fg=TITLE_TXT)
        self._wifi_st.pack(anchor="w")
        mid = tk.Frame(frm, bg=DARK_BG)
        mid.pack(fill="both", expand=True)
        self._wifi_list = tk.Listbox(mid, height=6, width=30,
                                     font=("Consolas", 12), bg=PANEL_BG,
                                     fg=FG_MAIN, selectbackground="#2b3540",
                                     exportselection=False)
        self._wifi_list.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(mid, command=self._wifi_list.yview)
        sb.pack(side="right", fill="y")
        self._wifi_list.config(yscrollcommand=sb.set)
        pwf = tk.Frame(frm, bg=DARK_BG)
        pwf.pack(fill="x", pady=4)
        tk.Label(pwf, text="密码:", font=("Microsoft YaHei", 11),
                 bg=DARK_BG, fg=FG_MAIN).pack(side="left")
        self._wifi_pwd = tk.StringVar()
        tk.Entry(pwf, textvariable=self._wifi_pwd, width=16, show="*",
                 font=("Consolas", 12), bg=FIELD_BG, fg=FG_MAIN,
                 insertbackground=FG_MAIN).pack(side="left", padx=2)
        btf = tk.Frame(frm, bg=DARK_BG)
        btf.pack(fill="x")
        tk.Button(btf, text="刷新", font=("Microsoft YaHei", 11),
                  bg=BTN_BG, fg=BTN_FG,
                  command=self._wifi_scan).pack(side="left", padx=2)
        tk.Button(btf, text="连接选中", font=("Microsoft YaHei", 11),
                  bg="#2e5d3b", fg="#d7ffe0",
                  command=self._wifi_connect).pack(side="left", padx=2)
        tk.Button(btf, text="关闭", font=("Microsoft YaHei", 11),
                  bg=BTN_BG, fg=BTN_FG,
                  command=win.destroy).pack(side="left", padx=2)
        self._wifi_win = win
        self._wifi_scan()

    def _wifi_scan(self):
        def fn():
            rc, out = self._nm(["-t", "-f", "ACTIVE,SSID,SIGNAL,SECURITY",
                                "dev", "wifi", "list"])
            nets, active, seen = [], "", set()
            for ln in out.splitlines():
                f_ = ln.split(":")
                if len(f_) < 4 or not f_[1]:
                    continue
                ssid = f_[1]
                if ssid in seen:
                    continue
                seen.add(ssid)
                mark = "√ " if f_[0].lower() == "yes" else ""
                if mark:
                    active = ssid
                nets.append((mark + ssid, f_[2], ":".join(f_[3:]), ssid))
            nets.sort(key=lambda x: x[1], reverse=True)
            return active, nets

        def done(res, err):
            if err or res is None:
                self._wifi_st.config(text="扫描失败(需NetworkManager)")
                return
            active, nets = res
            self._wifi_nets = {n[0]: n for n in nets}
            self._wifi_active = active
            self._wifi_list.delete(0, "end")
            for disp in self._wifi_nets:
                self._wifi_list.insert("end", disp)
            self._wifi_st.config(text=("当前: " + active) if active else "未连接")

        self._run_bg(fn, done)

    def _wifi_connect(self):
        sel = self._wifi_list.curselection()
        if not sel:
            messagebox.showinfo("提示", "请先在列表中选择网络",
                                parent=self._wifi_win)
            return
        disp = self._wifi_list.get(sel[0])
        net = getattr(self, "_wifi_nets", {}).get(disp)
        if not net:
            return
        ssid, sec = net[3], net[2]
        need_pwd = any(k in sec.upper()
                       for k in ("WPA", "PSK", "SAE", "802.1X"))
        pwd = self._wifi_pwd.get().strip()
        if need_pwd and not pwd:
            messagebox.showinfo("提示", "该网络需要密码，请先输入或点【键盘】",
                                parent=self._wifi_win)
            return
        self._wifi_st.config(text=f"连接 {ssid} 中...")
        self._wifi_list.config(state="disabled")

        def fn():
            args = ["dev", "wifi", "connect", ssid]
            if pwd:
                args += ["password", pwd]
            return self._nm(args, timeout=45)

        def done(res, err):
            self._wifi_list.config(state="normal")
            if err:
                self._wifi_st.config(text="连接出错")
                messagebox.showerror("WiFi", str(err), parent=self._wifi_win)
                return
            rc, out = res
            if rc == 0 and "successfully" in out.lower():
                self._wifi_st.config(text=f"已连接 {ssid}")
            else:
                msg = (out or "").strip().splitlines()
                self._wifi_st.config(text="连接失败")
                messagebox.showerror("WiFi", (msg[-1] if msg else "失败")[:160],
                                     parent=self._wifi_win)
            self._wifi_scan()

        self._run_bg(fn, done)

    # ---------- 触屏：关机 / 重启 ----------

    def _power_act(self, action, name):
        if not messagebox.askyesno("确认", f"确认立即{name}？"):
            return
        self.info_var.set(f"正在{name}，屏幕将熄灭...")
        subprocess.Popen(["sudo", "-n", "systemctl", action])

    def _power_reboot(self):
        self._power_act("reboot", "重启系统")

    def _power_off(self):
        self._power_act("poweroff", "关机")

    # ---------- 五大指数 ----------

    def _update_indices(self):
        codes = [c for c, _ in INDEX_CODES]

        def fn():
            data = {}
            raw = http_get(QT_URL + ",".join(codes))
            for seg in raw.split(";"):
                seg = seg.strip()
                if "=" not in seg or "~" not in seg:
                    continue
                code = seg.split("=")[0].strip().replace("v_", "", 1).lower()
                f = seg.split("~")
                if len(f) < 34 or not f[3]:
                    continue
                try:
                    data[code] = {"name": f[1], "price": float(f[3]),
                                  "chg": float(f[32])}
                except ValueError:
                    continue
            return data

        def done(data, err):
            self.idx_data = data or {}
            for code, name in INDEX_CODES:
                lp, lc = self.idx_labels[code]
                info = (data or {}).get(code)
                if info:
                    lp.config(text=f"{info['price']:.2f}")
                    chg = info["chg"]
                    lc.config(text=f"{chg:+.2f}%",
                              fg=UP if chg >= 0 else DOWN)
                else:
                    lp.config(text="-")
                    lc.config(text="-", fg=AXIS_TXT)
        self._run_bg(fn, done)

    def _index_loop(self):
        self._update_indices()
        self.root.after(30000, self._index_loop)

    def copy_report(self):
        if not self.res:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(self._report_text())
        self.info_var.set("报告已复制到剪贴板")

    def export_report(self):
        if not self.res:
            return
        desk = os.path.join(os.path.expanduser("~"), "Desktop")
        if not os.path.isdir(desk):
            desk = os.path.expanduser("~")
        fn = filedialog.asksaveasfilename(
            initialdir=desk,
            initialfile=f"预测_{self.res['full_code']}_{time.strftime('%Y%m%d')}.txt",
            defaultextension=".txt",
            filetypes=[("文本文件", "*.txt")])
        if not fn:
            return
        with open(fn, "w", encoding="utf-8") as f:
            f.write(self._report_text())
            f.write("\n\n-- 相似样本明细 --\n")
            for s in self.res["samples"]:
                f.write(json.dumps(s, ensure_ascii=False) + "\n")
            f.write(f"\n作者：{AUTHOR}  邮箱：{AUTHOR_EMAIL}  "
                    f"QQ：{AUTHOR_QQ}\n{DISCLAIMER}\n")
        self.info_var.set(f"已导出: {fn}")

    def show_samples(self):
        if not self.res:
            return
        win = tk.Toplevel(self.root)
        win.title(f"相似样本明细 - {self.res['full_code']}")
        txt = tk.Text(win, width=110, font=("Consolas", 9))
        txt.pack(fill="both", expand=True)
        hdr = (f"{'T日':<11}{'T+1日':<11}{'T+2日':<11}{'缺口%':>7}{'高/开%':>8}"
               f"{'低/开%':>8}{'收/开%':>8}{'T2高/开%':>9}{'T2低/开%':>9}{'T2收/开%':>9}\n")
        txt.insert("end", hdr)
        for s in self.res["samples"]:
            txt.insert("end",
                       f"{s['t_date']:<11}{s['n1_date']:<11}{s['n2_date']:<11}"
                       f"{s['gap']*100:>7.2f}{s['hi_o']*100:>8.2f}"
                       f"{s['lo_o']*100:>8.2f}{s['cl_o']*100:>8.2f}"
                       f"{s['t2_hi']*100:>9.2f}{s['t2_lo']*100:>9.2f}"
                       f"{s['t2_cl']*100:>9.2f}\n")

    # ---------- AI 分析（DeepSeek） ----------

    def _ai_prompt(self):
        res, tp, pred = self.res, self.res["t_pred"], self.res["pred"]
        q = res["quote"]
        ind = res["ind"]
        last = lambda a: next((v for v in reversed(a) if v is not None), None)
        f3 = lambda v: f"{v:.3f}" if isinstance(v, (int, float)) else "-"
        f1 = lambda v: f"{v:.1f}" if isinstance(v, (int, float)) else "-"
        bars = res["disp_rows"][-10:]
        kline_txt = "\n".join(
            f"{b['date']} 开{b['open']:.2f} 高{b['high']:.2f} "
            f"低{b['low']:.2f} 收{b['close']:.2f} 量{b.get('vol') or 0:.0f}"
            for b in bars)
        sig_txt = "; ".join(f"{d}[{t}]{x}" for _, d, t, x in res["signals"][-6:]) or "无"
        sm = res["samples"]
        avg_t1 = sum(s["cl_o"] for s in sm) / len(sm) * 100
        idx_txt = (f"{res['idx_chg_today']:+.2f}%"
                   if res["idx_chg_today"] is not None else "数据不足")
        vr_txt = (f"量比 {res['vr_now']:.2f}（{res['cur_regime']}）"
                  if res["vr_now"] is not None else "数据不足")
        sec_txt = (f"{res['sector_name']}今日 {res['sector_chg_today']:+.2f}%"
                   if res["sector_name"] and res["sector_chg_today"] is not None
                   else "板块数据不足")
        return (
            f"你是专业A股分析师。请基于以下数据给出简短分析（300字内），"
            f"包含：1)技术面与量价配合解读(MA/MACD/KDJ/RSI/量能) "
            f"2)结合大盘、板块环境与统计预测的短线(1-3日)操作建议 3)风险提示。"
            f"用中文，直接给结论。\n\n"
            f"股票：{q['name']}({res['full_code']}) 快照{q['time']}\n"
            f"昨收{res['prev_close']:.2f} 今开{q['open']:.2f}"
            f"(缺口{res['gap_today']:+.2f}%) 现价{q['price']:.2f}\n"
            f"大盘：上证指数今日 {idx_txt}；本股量能：{vr_txt}；"
            f"板块：{sec_txt}\n\n"
            f"近10日行情：\n{kline_txt}\n\n"
            f"指标最新值：MA5={f3(last(ind['ma'][5]))} MA10={f3(last(ind['ma'][10]))} "
            f"MA20={f3(last(ind['ma'][20]))} MA60={f3(last(ind['ma'][60]))}\n"
            f"DIF={f3(last(ind['dif']))} DEA={f3(last(ind['dea']))} "
            f"MACD柱={f3(last(ind['mhist']))}\n"
            f"K={f1(last(ind['k']))} D={f1(last(ind['d']))} J={f1(last(ind['j']))}\n"
            f"RSI6={f1(last(ind['rsi6']))} RSI12={f1(last(ind['rsi12']))}\n\n"
             f"历史形态统计预测(锚定{res.get('anchor', '今开')})：\n"
            f"今日收盘 P50={tp['cl'][50]:.2f}(P10 {tp['cl'][10]:.2f}/"
            f"P90 {tp['cl'][90]:.2f}) 上行概率{tp['up_prob']*100:.0f}%\n"
            f"{res.get('next_label', '次日(T+1)')}预测 开{pred['open']:.2f} 收{pred['close']:.2f} "
            f"高{pred['high']:.2f} 低{pred['low']:.2f}\n"
            f"相似样本{len(sm)}个, 样本次日平均涨跌{avg_t1:+.2f}%\n"
            f"近期信号：{sig_txt}"
        )

    def ai_analyze(self):
        if not self.res:
            messagebox.showinfo("提示", "请先【分析预测】一只股票")
            return
        key = self.api_key
        if not key:
            key = simpledialog.askstring(
                "DeepSeek API Key",
                "首次使用请输入 DeepSeek API Key\n(仅保存在本地 stock_gui.ini)：",
                show="*", parent=self.root)
            if not key:
                return
            self.api_key = key.strip()
            self._save_ini()
        prompt = self._ai_prompt()
        self.btn_ai.config(state="disabled")
        self.info_var.set("DeepSeek 分析中...")
        self._run_bg(lambda: deepseek_chat(self.api_key, prompt),
                     self._ai_done)

    def _ai_done(self, text, err):
        self.btn_ai.config(state="normal")
        if err:
            self.info_var.set("AI分析失败")
            messagebox.showerror(
                "AI 分析失败",
                f"{err}\n\n请检查 API Key 与网络后重试（设置里可修改 Key）。")
            return
        self.ai_text = text
        self.info_var.set("AI分析完成（见右侧预测参考栏）")
        self._write_side()
        self.side_txt.see("end")

    # ---------- 设置 ----------

    def open_settings(self):
        win = tk.Toplevel(self.root)
        win.title("设置")
        win.configure(bg=DARK_BG)
        win.transient(self.root)
        win.resizable(False, False)
        frm = ttk.Frame(win, padding=14)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="界面主题").grid(row=0, column=0, sticky="w", pady=4)
        theme_var = tk.StringVar(value=self.settings["theme"])
        ttk.Radiobutton(frm, text="暗色", variable=theme_var,
                        value="dark").grid(row=0, column=1, sticky="w")
        ttk.Radiobutton(frm, text="亮色", variable=theme_var,
                        value="light").grid(row=0, column=2, sticky="w")

        ttk.Label(frm, text="涨跌配色").grid(row=1, column=0, sticky="w", pady=4)
        ud_var = tk.StringVar(value=self.settings["updown"])
        ttk.Radiobutton(frm, text="红涨绿跌", variable=ud_var,
                        value="red_up").grid(row=1, column=1, sticky="w")
        ttk.Radiobutton(frm, text="绿涨红跌", variable=ud_var,
                        value="green_up").grid(row=1, column=2, sticky="w")

        ttk.Label(frm, text="DeepSeek Key").grid(row=2, column=0, sticky="w",
                                                 pady=(8, 4))
        key_var = tk.StringVar(value=self.api_key)
        ent = ttk.Entry(frm, textvariable=key_var, width=42, show="*")
        ent.grid(row=2, column=1, columnspan=2, sticky="we", pady=(8, 4))

        ttk.Label(frm, text="网络代理").grid(row=3, column=0, sticky="w",
                                            pady=4)
        proxy_var = tk.StringVar(value=getattr(self, "proxy_url", ""))
        ent_px = ttk.Entry(frm, textvariable=proxy_var, width=42)
        ent_px.grid(row=3, column=1, columnspan=2, sticky="we", pady=4)

        def save():
            self.settings["theme"] = theme_var.get()
            self.settings["updown"] = ud_var.get()
            new_key = key_var.get().strip()
            key_changed = new_key != self.api_key
            self.api_key = new_key
            self.proxy_url = proxy_var.get().strip()
            if CACHE_OK:
                set_proxy(self.proxy_url)
                self._save_ini()
            apply_theme(self.settings["theme"], self.settings["updown"])
            self._rebuild_ui()
            win.destroy()
            self.info_var.set(
                "设置已保存" + (f"，代理 {self.proxy_url}" if self.proxy_url
                                else "（未用代理）"))

        def clear_cache():
            if not messagebox.askyesno(
                    "清除缓存",
                    "确定清空本地缓存数据库？\n\n"
                    "将删除：日K历史 / 全市场代码表 / 样本池 / 失败记录\n"
                    "下次分析时会自动重新回填（约1-2分钟）"):
                return
            try:
                conn = _cx()
                try:
                    for t in ("daily_bars", "failed", "stocks", "meta"):
                        conn.execute(f"DELETE FROM {t}")
                    conn.commit()
                finally:
                    conn.close()
                messagebox.showinfo("清除缓存",
                                    "已清空 stock_cache.db\n"
                                    "下次分析将重新回填样本池")
            except Exception as e:
                messagebox.showerror("清除缓存", str(e))

        btns = ttk.Frame(frm)
        btns.grid(row=4, column=0, columnspan=3, pady=(12, 0))
        ttk.Button(btns, text="保存并应用", command=save).pack(
            side="left", padx=4)
        ttk.Button(btns, text="清除缓存", command=clear_cache).pack(
            side="left", padx=4)

        # ---- 关于 / 免责声明 ----
        sep = ttk.Separator(frm, orient="horizontal")
        sep.grid(row=5, column=0, columnspan=3, sticky="we", pady=(14, 8))
        about = tk.Text(frm, width=52, height=11, relief="flat",
                        bg=PANEL_BG, fg=FG_MAIN, font=("Microsoft YaHei", 9),
                        wrap="word", highlightthickness=0)
        about.grid(row=6, column=0, columnspan=3, sticky="we")
        about.insert("end", "作者：獨白\n")
        about.insert("end", "邮箱：kingrux106@gmail.com\n")
        about.insert("end", "QQ：2180287399\n")
        about.insert("end", "\n【免责声明】\n")
        about.insert(
            "end",
            "本程序所有内容（包括但不限于K线、指标、形态相似度统计预测、"
            "AI分析）仅为历史数据的技术统计与个人学习研究用途，"
            "不构成任何投资建议或收益承诺。股票有风险，"
            "据此操作产生的盈亏与后果由使用者自行承担。"
            "请遵守所在地区法律法规，理性投资。")
        about.config(state="disabled")

    def _rebuild_ui(self):
        """销毁重建全部控件（主题切换后刷新配色）。"""
        for w in self.root.winfo_children():
            w.destroy()
        self.scales = {}
        self.view = None
        self._style_ttk()
        self._build_toolbar()
        self._build_body()
        self._render_watchlist()
        if self.res:
            self._rerender()
        self._update_indices()


def main():
    try:
        import sys
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
